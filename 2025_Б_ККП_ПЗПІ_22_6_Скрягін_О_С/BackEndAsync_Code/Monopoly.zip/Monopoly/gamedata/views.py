from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from django.conf import settings
from .models import UserStat
from .serializers import UserStatSerializer, UserRankSerializer
import requests
from django.shortcuts import redirect
from registration.models import User
from .models import GameHistory
from .serializers import GameHistorySerializer
from django.shortcuts import get_object_or_404
from django.db import transaction



class AllTimePlayers(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        top_players = UserStat.objects.order_by('-points')[:10]
        serializer = UserStatSerializer(top_players, many=True)
        return Response({'players': serializer.data})


class UserGameHistoryView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        user = request.user
        games = GameHistory.objects.filter(user=user).order_by('-played_at')
        serializer = GameHistorySerializer(games, many=True)

        return Response(serializer.data,status=status.HTTP_201_CREATED)

RATINGS = {
    1: 100,
    2: 50,
    3: 25,
    4: 0
}

MONEY = {
    1: 500,
    2: 250,
    3: 100,
    4: 50
}

class AddGameRecordView(APIView):
    @transaction.atomic
    def post(self, request):
        data = request.data
        users = data.get('users', [])
        duration = data.get('duration')
        played_at = data.get('played_at')

        if not users or duration is None or played_at is None:
            return Response({'error': 'Недостатньо даних'}, status=status.HTTP_400_BAD_REQUEST)

        results = []

        for u in users:
            id = int(u.get('id'))
            place = int(u.get('place'))
            rating = RATINGS.get(place)
            money = MONEY.get(place)
            result = "Поразка"
            user = get_object_or_404(User, id=id)
            user.game_currency += money
            user.save()
            user_stat, created = UserStat.objects.get_or_create(user=user)
            user_stat.games += 1
            if place == 1:
                user_stat.wins += 1
                result = "Перемога"

            user_stat.points += rating
            user_stat.save()

            game = GameHistory(
                user=user,
                result=result,
                points_earned=rating,
                duration_minutes=duration,
                played_at=played_at
            )
            game.save()
            results.append(game)

        serializer = GameHistorySerializer(results, many=True)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class UserRankView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user = request.user

        try:
            user_stat = UserStat.objects.get(user=user)
        except UserStat.DoesNotExist:
            return Response({'detail': 'User statistics not found.'}, status=status.HTTP_404_NOT_FOUND)

        all_stats = UserStat.objects.order_by('-points')

        rank = 1
        found_rank = False
        for stat in all_stats:
            if stat.user == user:
                found_rank = True
                break
            rank += 1
        
        if not found_rank:
            rank = -1

        data = {
            'points': user_stat.points,
            'rank': rank
        }
        serializer = UserRankSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        return Response(serializer.data, status=status.HTTP_200_OK)