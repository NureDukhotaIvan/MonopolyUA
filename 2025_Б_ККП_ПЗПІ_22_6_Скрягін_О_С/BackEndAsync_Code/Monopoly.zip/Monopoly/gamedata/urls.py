from django.urls import path
from .views import AllTimePlayers, AddGameRecordView, UserGameHistoryView, UserRankView


urlpatterns = [
    path('best-players/', AllTimePlayers.as_view(), name='best-players'),
    path('add-game/', AddGameRecordView.as_view(), name='add-game-record'),
    path('history/', UserGameHistoryView.as_view()),
    path('user-rank/', UserRankView.as_view(), name='user-rank'),
]