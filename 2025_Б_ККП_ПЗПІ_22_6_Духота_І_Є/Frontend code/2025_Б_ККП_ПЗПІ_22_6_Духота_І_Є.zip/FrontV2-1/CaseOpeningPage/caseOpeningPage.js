//---Повний кейс опенінг---
document.addEventListener('DOMContentLoaded', async () => {

  const title = document.getElementById('title');
  let items;
  let case_info;

  function getCaseIdFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get('case_id');
  }

  const caseId = getCaseIdFromUrl();

  if (!caseId) {
    alert('Case ID не знайдено в URL');
    return;
  }

  async function fetchCase(caseId) {
    const response = await fetch(`http://localhost:8000/market/user-inventory/${caseId}/`, {
      headers: {
        'Authorization': 'Bearer ' + localStorage.getItem('authToken')
      }
    });
    return response.json();
  }

  async function fetchCaseItems(caseId) {
    const response = await fetch(`http://localhost:8000/market/case-items/${caseId}`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        'Content-Type': 'application/json'
      }
    });
    if (!response.ok) {
      throw new Error('Failed to load case items');
    }
    return response.json();
  }

  function createItemElement(item) {
    const div = document.createElement('div');
    div.classList.add('potential-drop-item');
    const img = document.createElement('img');
    img.src = item.image;
    img.alt = item.name;

    const name = document.createElement('p');
    name.textContent = item.name;



    div.appendChild(img);
    div.appendChild(name);

    return div;
  }

  function fillDropLines(items) {
    const dropLine1 = document.querySelector('.potential-drop-line1');
    const dropLine2 = document.querySelector('.potential-drop-line2');

    dropLine1.innerHTML = '';
    dropLine2.innerHTML = '';
    items = items.case_items;
    items.slice(0, 9).forEach(item => {
      dropLine1.appendChild(createItemElement(item));
    });

    if (items.length > 9) {
      items.slice(9).forEach(item => {
        dropLine2.appendChild(createItemElement(item));
      });
    }
  }

  function fillDropLineRandom(items) {
    items = items.case_items;
    const dropLine = document.querySelector('.drop-line');
    dropLine.innerHTML = '';

    const shuffled = [...items].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, 7);

    selected.forEach(item => {
      dropLine.appendChild(createItemElement(item));
    });
  }

  try {
    items = await fetchCaseItems(caseId);
    case_info = await fetchCase(caseId);
    console.log(case_info);
    title.textContent = items.name + " x " + case_info.quantity;
    fillDropLines(items);
    fillDropLineRandom(items);
  } catch (e) {
    console.error('Error loading case items:', e);
    alert('Не вдалося завантажити предмети кейсу.');
  }

  const button = document.getElementById('caseOpen');
  const dropLine = document.querySelector('.drop-line');
  let isAnimating = false;
  let selectedItemFromServer = null;

  button.addEventListener('click', async () => {
    if (isAnimating) return;

    if (button.textContent === "Забрати") {
      window.location.reload();
      return;
    }

    isAnimating = true;
    button.disabled = true;

    try {
      const response = await fetch('http://localhost:8000/market/open-case/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        },
        body: JSON.stringify({ case_id: caseId }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        alert(`Помилка: ${errorData.detail || 'Сервер не відповідає'}`);
        isAnimating = false;
        button.disabled = false;
        return;
      }

      selectedItemFromServer = await response.json();

      startAnimation();

    } catch (error) {
      alert(error);
      isAnimating = false;
      button.disabled = false;
    }
  });

  function startAnimation() {
    title.textContent = items.name + " x " + case_info.quantity;
    const moveTime = 50;
    const duration = 10000;
    const itemWidth = dropLine.firstElementChild.offsetWidth + 20;
    button.disabled = true;
    dropLine.style.transition = `transform ${moveTime}ms ease-in-out`;

    const shuffleInsert = (element) => {
      const children = Array.from(dropLine.children);
      const randomIndex = Math.floor(Math.random() * children.length);
      dropLine.insertBefore(element, dropLine.children[randomIndex]);
    };

    let animationFrameId;
    let stopped = false;

    const animate = () => {
      if (stopped) return;

      dropLine.style.transform = `translateX(-${itemWidth}px)`;

      setTimeout(() => {
        if (stopped) return;

        dropLine.style.transition = 'none';
        dropLine.style.transform = 'translateX(0)';

        const first = dropLine.firstElementChild;
        shuffleInsert(first);

        void dropLine.offsetWidth;
        dropLine.style.transition = `transform ${moveTime}ms ease-in-out`;

        animationFrameId = requestAnimationFrame(animate);
      }, moveTime);
    };

    animate();

    setTimeout(() => {
      stopped = true;
      cancelAnimationFrame(animationFrameId);
      isAnimating = false;
      button.disabled = false;

      dropLine.style.transition = 'none';
      dropLine.style.transform = 'none';

      dropLine.innerHTML = '';
      const resultItem = createItemElement(selectedItemFromServer);
      resultItem.classList.add('highlighted-item');
      dropLine.appendChild(resultItem);

      button.textContent = "Забрати";
    }, duration);
  }
})