//---Слайдер інформації---
let currentSlide = 0;
const slides = document.querySelector('.slides');
const totalSlides = 6;
let slideInterval = startSlideInterval();

function startSlideInterval() {
  return setInterval(() => {
    moveSlide(1);
  }, 10000);
}

function moveSlide(step) {
  currentSlide = (currentSlide + step + totalSlides) % totalSlides;
  updateSlide();
}

function updateSlide() {
  slides.style.transform = `translateX(-${currentSlide * 100}%)`;
}

function nextSlide() {
  clearInterval(slideInterval);
  moveSlide(1);
  slideInterval = startSlideInterval();
}

function prevSlide() {
  clearInterval(slideInterval);
  moveSlide(-1);
  slideInterval = startSlideInterval();
}

document.querySelector('.next').addEventListener('click', nextSlide);
document.querySelector('.prev').addEventListener('click', prevSlide);

const watchBtn = document.querySelector('.watch-video-btn');
const closeBtn = document.querySelector('.close-video-btn');
const containerVideo = document.querySelector('.container-video');

watchBtn.addEventListener('click', () => {
  containerVideo.classList.add('active');

  setTimeout(() => {
    containerVideo.classList.add('show-video');
  }, 1000);
});

closeBtn.addEventListener('click', () => {
  containerVideo.classList.remove('show-video');

  setTimeout(() => {
    containerVideo.classList.remove('active');
  }, 300);
});
//---Слайдер інформації---

//---Таблиця найкращих гравців---
async function loadAllTimePlayers() {
  try {
    const response = await fetch('http://localhost:8000/statistic/best-players/', {
      headers: {
        'Authorization': 'Bearer ' + localStorage.getItem('authToken')
      }
    });
    if (!response.ok) throw new Error('Failed to fetch players');

    const data = await response.json();
    renderTable(data.players, 'alltime-table');
  } catch (error) {
    console.error('Помилка виведення гравців:', error);
  }
}

function renderTable(players, tableId) {
  const tableBody = document.getElementById(tableId).querySelector('tbody');
  tableBody.innerHTML = '';

  players.forEach((player, index) => {

    const row = `
      <tr>
        <td>${index + 1}</td>
        <td>${player.username}</td>
        <td>${player.games}</td>
        <td>${player.wins}</td>
        <td>${player.win_percent}%</td>
        <td>${player.points}</td>
      </tr>
    `;
    tableBody.innerHTML += row;
  });
}

loadAllTimePlayers();

document.querySelector('.scroll-to-rules').addEventListener('click', function (e) {
  e.preventDefault();

  document.querySelector('.container-rules').scrollIntoView({
    behavior: 'smooth'
  });
});
//---Таблиця найкращих гравців---