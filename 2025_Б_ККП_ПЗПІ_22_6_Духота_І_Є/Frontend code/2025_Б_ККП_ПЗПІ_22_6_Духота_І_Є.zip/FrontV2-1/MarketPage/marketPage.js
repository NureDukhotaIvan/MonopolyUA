//---Повний маркет---
let items = [];
let activeType = null;
const itemDisplayMid = document.querySelector('.item-display-mid');
const searchNameInput = document.getElementById('search-name');
const typeButtons = document.querySelectorAll('.type-btn');
const priceFromInput = document.getElementById('price-from');
const priceToInput = document.getElementById('price-to');
const raritySelect = document.getElementById('rarity-select');
const amountInput = document.getElementById('amount');

function createItemElement(item) {
    const itemElement = document.createElement('div');
    itemElement.classList.add('item');
    itemElement.dataset.itemId = item.id;

    itemElement.innerHTML = `
        <div class="text">
            <h3>${item.name}</h3>
            <p>Ціна: ${item.price}</p>
            <p>Рідкість: ${item.rarity}</p>
            <p>Кількість: ${item.amount}</p>
        </div>
        <div class="image-wrapper">
            <img src="${item.image}" alt="${item.name}">
        </div>
    `;
    return itemElement;
}

function updateItems() {
    const nameFilter = searchNameInput.value.toLowerCase();
    const priceMin = parseInt(priceFromInput.value) || 0;
    const priceMax = parseInt(priceToInput.value) || Infinity;
    const rarityFilter = raritySelect.value;
    const amountFilter = parseInt(amountInput.value) || 0;

    itemDisplayMid.innerHTML = '';

    const filteredItems = items.filter(item => {
        const matchesName = item.name.toLowerCase().includes(nameFilter);
        const matchesPrice = item.price >= priceMin && item.price <= priceMax;
        const matchesRarity = rarityFilter === 'all' || item.rarity === rarityFilter;
        const matchesAmount = (item.amount ?? Infinity) >= amountFilter;

        const matchesType = !activeType || item.category === activeType || item.type === activeType;

        return matchesName && matchesPrice && matchesRarity && matchesAmount && matchesType;
    });

    filteredItems.forEach(item => {
        const itemElement = createItemElement(item);
        itemDisplayMid.appendChild(itemElement);
    });
}

const modal = document.getElementById('modal');
const closeBtn = modal.querySelector('.close');

closeBtn.addEventListener('click', () => {
    modal.classList.add('hidden');
});

document.addEventListener('dblclick', async (event) => {
    const itemElement = event.target.closest('.item');
    if (!itemElement) return;

    const itemId = itemElement.dataset.itemId;
    if (!itemId) return;

    try {
        const response = await fetch(`http://localhost:8000/market/item/${itemId}`, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
            }
        });

        if (!response.ok) throw new Error('Failed to fetch item data');

        const itemData = await response.json();

        modal.querySelector('#modal-title').textContent = `Item: ${itemData.item.name}`;
        modal.querySelector('#priceForItem').value = itemData.item.price || '';
        modal.querySelector('#amountOfItem').value = 1;
        modal.querySelector('.buy-menu-image').src = itemData.item.image || '';
        modal.querySelector('.buy-menu-image').alt = itemData.item.name || 'Item image';
        modal.querySelector('#min-price').textContent = `Від ${itemData.item.min_price}`;
        modal.querySelector('#max-quantity').textContent = `До ${itemData.item.amount}`;
        modal.dataset.itemId = itemData.item.id;

        const marketContainer = modal.querySelector('.modal-content-bot');
        marketContainer.innerHTML = '';
        const slowBuyBtn = modal.querySelector('.slowbuy-btn');

        slowBuyBtn.onclick = async () => {
            const priceInput = modal.querySelector('#priceForItem').value.trim();
            const amountInput = modal.querySelector('#amountOfItem').value.trim();
            const price = parseFloat(priceInput);
            const amount = parseInt(amountInput);

            if (isNaN(price) || price <= 0) {
                alert('Введіть коректну ціну');
                return;
            }
            if (isNaN(amount) || amount <= 0) {
                alert('Введіть коректну кількість');
                return;
            }

            const itemId = modal.dataset.itemId;
            if (!itemId) {
                alert('Помилка: не знайдено ID товару');
                return;
            }

            try {
                const token = localStorage.getItem('authToken');
                if (!token) {
                    alert('Ви не авторизовані');
                    return;
                }

                slowBuyBtn.disabled = true;
                slowBuyBtn.textContent = 'Обробка...';
                const response = await fetch(`http://localhost:8000/market/item/buy-multiple/${modal.dataset.itemId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        user_price: price,
                        user_quantity: amount,
                    })
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    alert(errorData.message || 'Недостатно грошей або товару');
                } else {
                    const data = await response.json();
                    alert(data.message || 'Успішна покупка');
                    location.reload();
                }
            } catch (error) {
                console.error(error);
                alert('Помилка мережі або сервера');
            } finally {
                slowBuyBtn.disabled = false;
                slowBuyBtn.textContent = 'Купити';
            }
        };

        if (itemData.market_listings && itemData.market_listings.length > 0) {
            itemData.market_listings.forEach(listing => {
                const listingDiv = document.createElement('div');
                listingDiv.classList.add('sales-row');

                listingDiv.innerHTML = `
                    <div class="sales-row-1">
                        <img src="${itemData.item.image || '#'}" alt="${itemData.name}">
                        <p>${listing.seller_username}</p>
                    </div>
                    <div class="sales-row-2">
                        <p>Ціна: ${listing.user_price}$</p>
                    </div>
                    <div class="sales-row-3">
                        <button 
                            data-listing-id="${listing.id}" 
                            class="buy-listing-btn"
                            ${listing.is_own_listing ? 'style="display:none;"' : ''}
                        >
                            Купити
                        </button>
                    </div>
                `;

                marketContainer.appendChild(listingDiv);
            });
        } else {
            marketContainer.innerHTML = '<p>Немає пропозицій на ринку.</p>';
        }

        modal.classList.remove('hidden');
    } catch (error) {
        console.error('Error loading item:', error);
        alert('Помилка при завантаженні товару');
    }
});

modal.querySelector('.modal-content-bot').addEventListener('click', async (event) => {
    if (!event.target.classList.contains('buy-listing-btn')) return;

    const listingId = event.target.dataset.listingId;
    if (!listingId) return;

    try {
        const response = await fetch(`http://localhost:8000/market/item/buy/${listingId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
            },
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Purchase failed');
        }

        const result = await response.json();
        alert(result.message);

        modal.classList.add('hidden');
    } catch (error) {
        console.error('Error buying item:', error);
        alert('Помилка при купівлі товару: ' + error.message);
    }
});

const modalSales = document.getElementById('modal-sales');
const closeBtnSales = modalSales.querySelector('.close-sales');
const openBtnSales = document.getElementById('open-sales');
const salesContentBot = modalSales.querySelector('.modal-sales-content-bot');

openBtnSales.addEventListener('click', async (event) => {
    event.stopPropagation();
    modalSales.classList.remove('hidden');
    await loadUserListings();
});

closeBtnSales.addEventListener('click', (event) => {
    event.stopPropagation();
    modalSales.classList.add('hidden');
});

async function loadUserListings() {
    const token = localStorage.getItem('authToken');

    if (!token) {
        console.error('JWT токен не знайдено');
        return;
    }

    try {
        const response = await fetch('http://localhost:8000/market/user-sell/', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) throw new Error('Не вдалося завантажити ваші лоти');

        const listings = await response.json();

        salesContentBot.innerHTML = '';

        listings.forEach(listing => {
            const saleDiv = document.createElement('div');
            saleDiv.className = 'your-sale';

            saleDiv.innerHTML = `
                <div class="your-sale-1">
                    <img src="${listing.image}" alt="item">
                    <p>${listing.item_name || 'Назва предмету'}</p>
                </div>
                
                <div class="your-sale-2">
                    <p>Ціна: ${listing.user_price}$</p>
                </div>
                <div class="your-sale-3">
                    <button class="remove-sale-btn">Зняти з продажу</button>
                </div>
            `;

            const removeBtn = saleDiv.querySelector('.remove-sale-btn');
            removeBtn.addEventListener('click', async () => {
                try {
                    const deleteResponse = await fetch(`http://localhost:8000/market/user-sell/delete/${listing.id}`, {
                        method: 'DELETE',
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    });

                    if (!deleteResponse.ok) {
                        throw new Error('Не вдалося зняти лот з продажу');
                    }

                    saleDiv.remove();
                    console.log(`Лот з id ${listing.id} знято з продажу`);
                } catch (deleteError) {
                    console.error(deleteError);
                }
            });

            salesContentBot.appendChild(saleDiv);
        });

    } catch (error) {
        console.error('Помилка при завантаженні лотів:', error);
    }
}

async function loadItems() {
    try {
        const response = await fetch('http://localhost:8000/market/items/', {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('authToken')}`,

            }
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        items = await response.json();
        updateItems();
    } catch (error) {
        console.error('Failed to load items:', error);
        itemDisplayMid.innerHTML = '<p>Помилка завантаження товарів</p>';
    }
}

searchNameInput.addEventListener('input', updateItems);
typeButtons.forEach(button => {
    button.addEventListener('click', () => {
        if (activeType === button.dataset.type) {
            activeType = null;
            button.classList.remove('active');
        } else {
            activeType = button.dataset.type;
            typeButtons.forEach(b => b.classList.remove('active'));
            button.classList.add('active');
        }
        updateItems();
    });
});

priceFromInput.addEventListener('input', updateItems);
priceToInput.addEventListener('input', updateItems);
raritySelect.addEventListener('change', updateItems);
amountInput.addEventListener('input', updateItems);

loadItems();
//---Повний маркет---