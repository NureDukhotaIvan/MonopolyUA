let currentUserId = null;
let gameState = null;

//-------------------------------WSL-------------------------------
function initGameWebSocket() {
    const params = new URLSearchParams(window.location.search);
    const sessionId = params.get('session');
    if (!sessionId) {
        console.error('No sessionId in URL');
        return;
    }

    const token = localStorage.getItem('authToken');
    if (!token) {
        console.error('No authToken in localStorage');
        return;
    }

    const wsProtocol = window.location.protocol === 'https:' ? 'wss' : 'ws';
    const wsUrl = `${wsProtocol}://localhost:8000/ws/game/?session=${sessionId}&token=${token}`;

    const gameSocket = new WebSocket(wsUrl);

    gameSocket.addEventListener('open', () => {
        console.log('Game WebSocket connected (session=' + sessionId + ')');
        // alert('Game WebSocket connected (session=' + sessionId + ')')
    });

    gameSocket.addEventListener('message', (evt) => {
        const msg = JSON.parse(evt.data);
        switch (msg.type) {
            case 'init':
                currentUserId = msg.user_id;
                gameState = msg.state;
                renderPlayers(msg.state);
                renderTokens(msg.state);
                renderChatAndLogs(msg.state)
                renderPropertyOwnership(msg.state);
                handleTurnStateUpdate(msg.state.turn_state, true);
                console.log(msg.state);
                break;
            case 'player_move':
                moveToken(msg.user_id, msg.color, msg.to);
                break;
            case 'chat':
                appendChatMessage(msg);
                break;
            case 'game_log':
                appendChatLog(msg);
                break;
            case 'property_bought':
                handlePropertyBought(msg);
                updatePlayerBalance(msg.new_owner, msg.new_balance);
                break;
            case 'balance_update':
                handleBalanceUpdate(msg.balances);
                break;
            case 'message':
                showMessageModal(msg.message);
                break;

            case "build_house":
                addToActedList(msg.property_id, msg.owner_id);
                addHousesToColorCardByCell(msg.property_id, msg.houses);
                break;
            case "sell_house":
                addHousesToColorCardByCell(msg.property_id, msg.houses);
                break;

            case "property_mortgaged":
                drawLock(msg.property_id, msg.mortgage_turns_left, msg.color);
                break;
            case "property_redeemed":
                addToActedList(msg.property_id, msg.owner_id);
                eraseLock(msg.property_id);
                break;
            case "mortgage_batch_update":
                handleMortgageBatchUpdate(msg.updates);
                break;
            case "property_released":
                handlePropertyReleased(msg.property_id);
                break;

            case "turn_state_update":
                handleTurnStateUpdate(msg.turn_state, false);
                break;

            case 'player_bankrupt':
                alert('player_bankrupt')
                handlePlayerBankrupt(msg);
                break;

            default:
                console.warn('Unknown message type:', msg.type);
        }
    });

    gameSocket.addEventListener('close', () => {
        console.warn('Game WebSocket disconnected, retry in 1s');
        setTimeout(initGameWebSocket, 1000);
    });

    window.gameSocket = gameSocket;
}
//-------------------------------WSL-------------------------------


//-------------------------------Front-Elements-------------------------------
const playersContainer = document.getElementById('playersBlock');

// ===== INFO MODAL =====
const infoModal = document.getElementById('InfoModal');
const infoModalContent = document.getElementById('infoModalInner');
const closeInfoModalBtn = document.getElementById('closeInfoModalBtn');

// ===== DICE MODAL =====
const diceModal = document.getElementById('DiceModal');
const diceModalContent = document.getElementById('diceModalInner');
const closeDiceModalBtn = document.getElementById('closeDiceModalBtn');
const reopenDiceModalBtn = document.querySelector('.dice-reopen-btn');


//-------------------------------Front-Elements-------------------------------



//-------------------------------Card-Info-------------------------------
const GROUP_COLORS = {
    light_blue: "#3b82f6",
    yellow: "#eab308",
    green: "#84cc16",
    orange: "#f97316",
    brown: "#a16207",
    pink: "#ec4899",
    purple: "#8b5cf6",
    dark_blue: "#1e40af",
    automaker: "#ef4444",
    utility: "#ffffff"
};

function showPropertyModal(cellId) {
    const prop = gameState.properties[cellId];
    if (!prop) return;

    const actedRaw = gameState.players_data[currentUserId].acted_props || "[]";
    let actedList;
    try {
        actedList = JSON.parse(actedRaw);
    } catch {
        actedList = [];
    }
    const alreadyActed = actedList.includes(String(cellId));

    const name = prop.name || "(Без названия)";
    const groupName = prop.group || prop.type || "";
    const titleColor = GROUP_COLORS[groupName] || "#facc15";

    let ownerName = "Свободна";
    let ownerColor = "#ffffff";
    if (prop.owner) {
        const od = gameState.players_data[prop.owner];
        if (od && od.username) {
            ownerName = od.username;
            ownerColor = od.color || "#ffffff";
        } else {
            ownerName = `Игрок ${prop.owner}`;
        }
    }

    const headerHtml = `
      <h2 class="info-modal-title" style="color: ${titleColor}; margin-bottom: 6px;">
        ${name}
      </h2>
      <div style="margin-bottom: 14px; font-size: 0.95em; color: #eee;">
        <span>Власник:</span>
        <span style="color: ${ownerColor}; font-weight: 600; margin-left: 4px;">
          ${ownerName}
        </span>
      </div>
    `;

    const buyPrice = Number(prop.buy_price || 0);
    const housePrice = Number(prop.house_price || 0);
    const hotelPrice = Number(prop.hotel_price || 0);
    let rentArr = [];
    try {
        rentArr = JSON.parse(prop.rent || "[]");
    } catch {
        rentArr = [];
    }

    let bodyHtml = "";
    switch (prop.type) {
        case "company":
            const existingHouses = Number(prop.houses || 0);
            const builtText = existingHouses < 5
                ? `${existingHouses} ${existingHouses === 1 ? "дом" : "домов"}`
                : "1 отель";

            bodyHtml = `
                <table class="info-table">
                    <tr><td>Вартість купівлі:</td><td>${buyPrice}$</td></tr>
                    <tr><td>Дім:</td><td>${housePrice}$</td></tr>
                    <tr><td>Готель:</td><td>${hotelPrice}$</td></tr>
                </table>
                
                <table class="info-table">
                    <tr><td>Побудовано:</td><td>${builtText}</td></tr>
                </table>

                <table class="info-table">
                    <tr><td>Рента без будинків:</td><td>${rentArr[0] || 0}$</td></tr>
                    <tr><td>Рента з 1 будинком:</td><td>${rentArr[1] || 0}$</td></tr>
                    <tr><td>Рента з 2 будинками:</td><td>${rentArr[2] || 0}$</td></tr>
                    <tr><td>Рента з 3 будинками:</td><td>${rentArr[3] || 0}$</td></tr>
                    <tr><td>Рента з 4 будинками:</td><td>${rentArr[4] || 0}$</td></tr>
                    <tr><td>Рента з готелем:</td><td>${rentArr[5] || 0}$</td></tr>
                </table>
            `;
            break;

        case "automaker":
            bodyHtml = `
          <table class="info-table">
            <tr><td>Вартість купівлі:</td><td>${buyPrice}$</td></tr>
          </table>
          <div style="margin: 12px 0 6px; font-size: 0.95em; color: #eee;">
           Оренда для цього типу власності залежить від кількості активів у власника:
          </div>
          <table class="info-table" style="white-space: normal; word-break: break-word;">
            <tr><td>1 одиниця у власника:</td><td>${rentArr[0] || 0}$</td></tr>
            <tr><td>2 одиниця у власника:</td><td>${rentArr[1] || 0}$</td></tr>
            <tr><td>3 одиниця у власника:</td><td>${rentArr[2] || 0}$</td></tr>
            <tr><td>4 одиниця у власника:</td><td>${rentArr[3] || 0}$</td></tr>
          </table>
        `;
            break;

        case "utility":
            bodyHtml = `
          <table class="info-table">
            <tr><td>Вартість купівлі:</td><td>${buyPrice}$</td></tr>
          </table>
          <div style="margin: 12px 0 6px; font-size: 0.95em; color: #eee;">
            Для цього типу власності рента = (сума кубиків, що випали) × множник:
          </div>
          <table class="info-table">
            <tr><td>Множник при 1 активі:</td><td>× 4</td></tr>
            <tr><td>Множник при 2 активах:</td><td>× 10</td></tr>
          </table>
        `;
            break;

        default:
            bodyHtml = `
          <table class="info-table">
            <tr><td>Тип картки:</td><td>${prop.type}</td></tr>
          </table>
        `;
            break;
    }

    let interactionHtml = "";
    if (prop.owner === currentUserId) {

        const ts = gameState.turn_state;
        const payload = JSON.parse(ts.action_payload || '{}');

        const currentPlayer = ts.current_player;
        const currentPhase = ts.phase;

        const totalOwed = Number(payload.totalOwed || 0);
        const actualBalance = gameState.players_data[currentUserId].balance;

        isPayDebt = ts && currentPhase === 'await_pay_debt' &&
            currentPlayer === currentUserId && (actualBalance < totalOwed)

        isCurrentUserTurn = (currentPlayer === currentUserId && currentPhase === 'roll_dice');

        const isMortgaged = prop.mortgaged === "1";

        const sameGroupProps = Object.values(gameState.properties).filter(p =>
            p.group === prop.group && p.type === "company"
        );

        const hasAnyHouseInGroup = sameGroupProps.some(p =>
            p.owner === currentUserId && Number(p.houses || 0) > 0
        );
        const anyMortgagedInGroup = sameGroupProps.some(p =>
            p.mortgaged === "1"
        );

        const canMortgage = !hasAnyHouseInGroup && (isCurrentUserTurn || isPayDebt);
        const canRedeem = !hasAnyHouseInGroup && isCurrentUserTurn && !alreadyActed;

        const mortgageAttr = canMortgage ? "" : 'disabled style="opacity:0.4; cursor:not-allowed;"';
        const redeemAttr = canRedeem ? "" : 'disabled style="opacity:0.4; cursor:not-allowed;"';

        const mortgageSection = !isMortgaged
            ? `<button class="info-modal-button" id="mortgageBtn" ${mortgageAttr}>Залишити під заставу</button>`
            : `<button class="info-modal-button" id="redeemBtn" ${redeemAttr}>Викупити з-під застави</button>`;

        let houseSection = "";
        if (prop.type === "company") {
            const ownsFullGroup = sameGroupProps.every(p => p.owner === currentUserId);

            if (ownsFullGroup) {
                const existingHouses = Number(prop.houses || 0);
                const canBuild = existingHouses < 5 && isCurrentUserTurn && !alreadyActed && !anyMortgagedInGroup;
                const canSell = existingHouses > 0 && (isCurrentUserTurn || isPayDebt);

                const buildCost = existingHouses < 4
                    ? housePrice
                    : existingHouses < 5
                        ? hotelPrice
                        : 0;

                const sellCost = existingHouses > 4
                    ? hotelPrice
                    : existingHouses > 0
                        ? housePrice
                        : 0;

                const buildAttr = canBuild ? "" : 'disabled style="opacity:0.4; cursor:not-allowed;"';
                const sellAttr = canSell ? "" : 'disabled style="opacity:0.4; cursor:not-allowed;"';

                houseSection = `
                    <div style="text-align: center;">
                    <button id="buildHouseBtn" class="info-modal-button" ${buildAttr}>
                        <img
                        src="http://localhost:8000/media/icons/add_house.png"
                        alt="Побудувати"
                        style="width: 24px; height: 24px;"
                        />
                    </button>
                    <div style="margin-top: 4px; font-size: 0.9em; color: #eee;">
                        -${buildCost}$
                    </div>
                    </div>

                    <div style="text-align: center;">
                    <button id="sellHouseBtn" class="info-modal-button" ${sellAttr}>
                        <img
                        src="http://localhost:8000/media/icons/remove_house.png"
                        alt="Продати"
                        style="width: 24px; height: 24px;"
                        />
                    </button>
                    <div style="margin-top: 4px; font-size: 0.9em; color: #eee;">
                        +${sellCost}$
                    </div>
                    </div>
                `;
            }
        }

        interactionHtml = `
          <div style="display: flex; gap: 18px; align-items: flex-start; margin: 10px 0;">
            ${mortgageSection}
            ${houseSection}
          </div>
        `;
    }

    infoModalContent.innerHTML = `
      ${headerHtml}
      ${bodyHtml}
      ${interactionHtml}
    `;
    infoModal.style.display = "flex";

    const mortgageBtn = document.getElementById("mortgageBtn");
    const redeemBtn = document.getElementById("redeemBtn");
    const buildHouseBtn = document.getElementById("buildHouseBtn");
    const sellHouseBtn = document.getElementById("sellHouseBtn");

    if (mortgageBtn) {
        mortgageBtn.addEventListener("click", () => {
            gameSocket.send(JSON.stringify({
                type: "mortgage_property",
                property_id: cellId
            }));
            infoModal.style.display = "none";
        });
    }
    if (redeemBtn) {
        redeemBtn.addEventListener("click", () => {
            gameSocket.send(JSON.stringify({
                type: "redeem_property",
                property_id: cellId
            }));
            infoModal.style.display = "none";
        });
    }
    if (buildHouseBtn) {
        buildHouseBtn.addEventListener("click", () => {
            gameSocket.send(JSON.stringify({
                type: "build_house",
                property_id: cellId
            }));
            infoModal.style.display = "none";
        });
    }
    if (sellHouseBtn) {
        sellHouseBtn.addEventListener("click", () => {
            gameSocket.send(JSON.stringify({
                type: "sell_house",
                property_id: cellId
            }));
            infoModal.style.display = "none";
        });
    }
}
//-------------------------------Card-Info-------------------------------


//-------------------------------Houses-------------------------------

function addToActedList(property_id, owner_id) {
    if (owner_id === currentUserId) {
        const actedRaw = gameState.players_data[currentUserId].acted_props || "[]";
        let actedList;
        try {
            actedList = JSON.parse(actedRaw);
        } catch {
            actedList = [];
        }
        if (!actedList.includes(property_id)) {
            actedList.push(property_id);
            gameState.players_data[currentUserId].acted_props = JSON.stringify(actedList);
        }
    }
}

function cleanActedList() {
    gameState.players_data[currentUserId].acted_props = [];
}

function addHousesToColorCardByCell(cellNumber, houseCount) {
    const cellElement = document.querySelector(`[data-cell="${cellNumber}"]`);
    if (!cellElement) {
        console.error(`❌ No element found with data-cell="${cellNumber}"`);
        return;
    }

    const idPrefixMatch = cellElement.id.match(/^(top|bot|left|right)CardImg(\d+)/);
    if (!idPrefixMatch) {
        console.error(`❌ Invalid ID format: ${cellElement.id}`);
        return;
    }

    const position = idPrefixMatch[1];
    const index = idPrefixMatch[2];

    const targetElement = document.getElementById(`${position}CardBuild${index}`);
    if (!targetElement) {
        console.error(`❌ Cannot find element with id=${position}CardBuild${index}`);
        return;
    }
    targetElement.innerHTML = "";

    for (let i = 0; i < houseCount; i++) {
        const house = document.createElement('div');
        house.classList.add('house');
        targetElement.appendChild(house);
    }

    if (
        gameState &&
        gameState.properties &&
        gameState.properties[cellNumber] !== undefined
    ) {
        gameState.properties[cellNumber].houses = String(houseCount);
    }
}
//-------------------------------Houses-------------------------------



//-------------------------------Pledge-------------------------------
function drawLock(cellNumber, turnsLeft, color = null) {
    const imgEl = document.querySelector(`[data-cell="${cellNumber}"]`);
    if (!imgEl) return;
    const wrapper = imgEl.parentElement;
    if (!wrapper) return;

    if (getComputedStyle(wrapper).position === "static") {
        wrapper.style.position = "relative";
    }

    const old = wrapper.querySelector(".mortgage-lock");
    if (old) old.remove();

    if (turnsLeft == 0) return;

    const lockContainer = document.createElement("div");
    lockContainer.className = "mortgage-lock";
    lockContainer.style.position = "absolute";
    lockContainer.style.pointerEvents = "none";

    if (wrapper.classList.contains("cards-top") || wrapper.classList.contains("board-top-sq")) {
        // Top:
        lockContainer.style.top = "4px";
        lockContainer.style.left = "50%";
        lockContainer.style.transform = "translateX(-50%)";
    } else if (wrapper.classList.contains("cards-bot") || wrapper.classList.contains("board-bot-sq")) {
        // Bottom:
        lockContainer.style.bottom = "0px";
        lockContainer.style.left = "50%";
        lockContainer.style.transform = "translateX(-50%)";
    } else if (wrapper.classList.contains("cards-left") || wrapper.closest(".board-mid-left")) {
        // Left:
        lockContainer.style.left = "0px";
        lockContainer.style.top = "50%";
        lockContainer.style.transform = "translateY(-50%)";
    } else if (wrapper.classList.contains("cards-right") || wrapper.closest(".board-mid-right")) {
        // Right:
        lockContainer.style.right = "0px";
        lockContainer.style.top = "50%";
        lockContainer.style.transform = "translateY(-50%)";
    } else {
        lockContainer.style.top = "50%";
        lockContainer.style.left = "50%";
        lockContainer.style.transform = "translate(-50%, -50%)";
    }

    let rgbNums = [0, 0, 0];
    const match = color.match(/rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/);
    if (match) {
        rgbNums = [match[1], match[2], match[3]];
    }
    const filename = `${rgbNums[0]}_${rgbNums[1]}_${rgbNums[2]}.png`;

    const lockImg = document.createElement("img");
    lockImg.src = `http://localhost:8000/media/icons/locks/${filename}`;
    lockImg.style.width = "45px";
    lockImg.style.height = "45px";
    lockImg.style.display = "block";
    lockImg.style.pointerEvents = "none";
    lockContainer.appendChild(lockImg);

    const numSpan = document.createElement("span");
    numSpan.textContent = turnsLeft;
    numSpan.style.position = "absolute";
    numSpan.style.top = "65%";
    numSpan.style.left = "50%";
    numSpan.style.transform = "translate(-50%, -50%)";
    numSpan.style.color = "#ffffff";
    numSpan.style.fontSize = "16px";
    numSpan.style.fontWeight = "bold";
    numSpan.style.pointerEvents = "none";
    lockContainer.appendChild(numSpan);

    wrapper.appendChild(lockContainer);

    if (
        gameState &&
        gameState.properties &&
        gameState.properties[cellNumber] !== undefined
    ) {
        gameState.properties[cellNumber].mortgaged = "1";
        gameState.properties[cellNumber].mortgage_turns_left = String(turnsLeft);
    }
}

function handleMortgageBatchUpdate(updates) {
    updates.forEach(update => {
        const cellNumber = Number(update.property_id);
        const turnsLeft = Number(update.turns_left);
        const color = update.color;
        drawLock(cellNumber, turnsLeft, color);
    });
}


function eraseLock(cellNumber) {
    const wrapper = document.querySelector(`[data-cell="${cellNumber}"]`).parentElement;
    const oldLock = wrapper.querySelector(".mortgage-lock");
    if (oldLock) oldLock.remove();

    if (
        gameState &&
        gameState.properties &&
        gameState.properties[cellNumber] !== undefined
    ) {
        gameState.properties[cellNumber].mortgaged = "0";
        gameState.properties[cellNumber].mortgage_turns_left = "0";
    }
}
//-------------------------------Pledge-------------------------------

window.addEventListener('load', initGameWebSocket);
window.addEventListener('DOMContentLoaded', () => {
    closeInfoModalBtn.addEventListener('click', () => {
        infoModal.style.display = 'none';
    });

    document.querySelectorAll(
        '.cards-top-img, .cards-left-img, .cards-right-img, .cards-bot-img'
    )
        .forEach(el => {
            el.addEventListener("click", () => {
                const cellId = el.getAttribute("data-cell");
                if (!cellId || !gameState || !gameState.properties[cellId]) return;

                showPropertyModal(cellId);
            });
        });

    //---------------------------------Friends---------------------------------
});


async function renderPlayers(state) {
    playersContainer.innerHTML = '';

    for (const userId of state.players) {
        const playerData = state.players_data[userId] || {};

        const balance = playerData.balance ?? 0;
        const color = playerData.color || 'red';
        const username = playerData.username || 'Player';
        const avatar = playerData.avatar || '';
        const place = playerData.place;

        const item = document.createElement('div');
        item.className = 'players-block-item';
        item.dataset.userId = userId;
        item.style.border = `2px solid ${color}`;
        item.tabIndex = 0;

        if (place) {
            item.classList.add('lost-player');
            item.style.opacity = '0.5';
        }

        const menuHTML = userId !== currentUserId
            ? `<div class="player-menu">
                   <button class="friend-btn">Додати у друзі</button>
               </div>`
            : '';

        item.innerHTML = `
            <img src="http://localhost:8000${avatar}" class="player-image" />
            <h1>${username}${place ? ` (місце ${place})` : ''}</h1>
            <p class="player-balance">${balance}$</p>
            ${menuHTML}
        `;

        if (userId !== currentUserId) {
            item.addEventListener('click', function (e) {
                document.querySelectorAll('.player-menu').forEach(menu => {
                    if (menu !== this.querySelector('.player-menu')) {
                        menu.style.display = 'none';
                    }
                });
                const menu = this.querySelector('.player-menu');
                menu.style.display = (menu.style.display === 'block') ? 'none' : 'block';
                e.stopPropagation();
            });

            const friendBtn = item.querySelector('.friend-btn');
            const token = localStorage.getItem('authToken');
            friendBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                friendBtn.disabled = true;
                friendBtn.style.opacity = '0.4';
                friendBtn.style.cursor = 'not-allowed';

                try {
                    const response = await fetch('http://localhost:8000/notifications/', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}`,
                        },
                        body: JSON.stringify({ receiver_id: userId })
                    });
                    if (!response.ok) throw new Error(`Server returned ${response.status}`);
                    alert('Запит на дружбу успішно надіслано!');
                } catch (err) {
                    console.error('Failed to send friend request', err);
                    friendBtn.disabled = false;
                    friendBtn.style.opacity = '';
                    friendBtn.style.cursor = '';
                }

                this.querySelector('.player-menu').style.display = 'none';
            });

            item.addEventListener('focusout', function (e) {
                const menu = this.querySelector('.player-menu');
                if (!this.contains(e.relatedTarget)) {
                    menu.style.display = 'none';
                }
            });
        }

        playersContainer.append(item);
    }

    document.addEventListener('click', () => {
        document.querySelectorAll('.player-menu')
            .forEach(menu => menu.style.display = 'none');
    });
}


function updatePlayerBalance(userId, newBalance) {
    gameState.players_data[userId].balance = newBalance;
    const item = document.querySelector(`.players-block-item[data-user-id="${userId}"]`);
    if (!item) return;
    const balEl = item.querySelector('.player-balance');
    balEl.textContent = `${newBalance}$`;

    const ts = gameState.turn_state;
    if (
        ts &&
        ts.phase === 'await_pay_debt' &&
        ts.current_player === currentUserId
    ) {
        const payload = JSON.parse(ts.action_payload || '{}');
        const startingCash = Number(payload.currentCash || 0);
        const totalOwed = Number(payload.totalOwed || 0);

        const alreadyReceived = Math.max(0, newBalance - startingCash);
        const shortfall = Math.max(0, totalOwed - startingCash);

        const receivEl = document.getElementById('debtReceived');
        if (receivEl) {
            receivEl.textContent = alreadyReceived;
        }
        const shortEl = document.getElementById('debtShortfall');
        if (shortEl) {
            shortEl.textContent = shortfall;
        }

        const payBtn = document.getElementById('payDebtBtn');
        if (payBtn) {
            if (newBalance >= totalOwed) {
                payBtn.disabled = false;
                payBtn.style.opacity = '';
                payBtn.style.cursor = '';
            } else {
                payBtn.disabled = true;
                payBtn.style.opacity = '0.4';
                payBtn.style.cursor = 'not-allowed';
            }
        }
    }
}

function handleBalanceUpdate(balances) {
    Object.entries(balances).forEach(([userId, newBalance]) => {
        updatePlayerBalance(userId, newBalance);
    });
}

//-------------------------------Message-------------------------------
document.querySelector('.send-button').addEventListener('click', () => {
    const input = document.querySelector('.message-input');
    const message = input.value.trim();

    if (message !== '') {
        const payload = {
            type: 'chat',
            text: message
        };
        gameSocket.send(JSON.stringify(payload));
        input.value = '';
    }
});

document.querySelector('.message-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        document.querySelector('.send-button').click();
    }
});


function appendChatMessage(msg) {
    const messageBlock = document.querySelector('.message-block');
    if (!messageBlock) return;

    const item = document.createElement('div');
    item.className = 'message-item';

    const h1 = document.createElement('h1');
    h1.textContent = msg.username + ':';
    h1.style.color = msg.color;

    const p = document.createElement('p');
    p.textContent = msg.text;
    p.style.margin = '0';

    item.appendChild(h1);
    item.appendChild(p);
    messageBlock.prepend(item);

    messageBlock.scrollTop = 0;
}


function renderChatAndLogs(state) {
    const messageBlock = document.querySelector('.message-block');
    messageBlock.innerHTML = '';

    const logs = (state.logs || []).map(raw => {
        const obj = typeof raw === 'string' ? JSON.parse(raw) : raw;
        return {
            ...obj,
            type: 'log'
        };
    });

    const chat = (state.chat || []).map(raw => {
        const obj = typeof raw === 'string' ? JSON.parse(raw) : raw;
        const pdata = state.players_data[obj.user_id] || {};
        return {
            ...obj,
            username: pdata.username || 'Unknown',
            color: pdata.color || '#888'
        };
    });

    const items = logs.concat(chat)
        .sort((a, b) => a.timestamp - b.timestamp);

    items.forEach(item => {
        if (item.type === 'chat') {
            appendChatMessage(item);
        } else {
            appendChatLog(item);
        }
    });

    messageBlock.scrollTop = messageBlock.scrollHeight;
}

//-------------------------------Loggs-------------------------------
function appendChatLog(log) {
    const messageBlock = document.querySelector('.message-block');

    const item = document.createElement('div');
    item.className = 'message-item log-item';

    const p = document.createElement('p');
    p.textContent = log.message;
    p.style.fontStyle = 'italic';
    p.style.color = '#666';
    p.style.margin = '0';

    item.appendChild(p);
    messageBlock.prepend(item);
}
//-------------------------------Message-------------------------------


//-------------------------------Tokens-------------------------------
function renderTokens(state) {
    document.querySelectorAll('.player-token').forEach(t => t.remove());

    state.players.forEach(userId => {
        const playerData = state.players_data[userId];
        if (!playerData || playerData.place) return;

        const cellIndex = parseInt(playerData.position, 10);
        createToken(userId, playerData.color, cellIndex);
    });
}

function removeToken(userId) {
    const token = document.querySelector(`.player-token[data-user-id='${userId}']`);
    if (token) token.remove();
}

function createToken(userId, color, cell) {
    const cellEl = document.querySelector(`[data-cell='${cell}']`);
    if (!cellEl) {
        console.warn(`Клетка data-cell="${cell}" не найдена`);
        return;
    }

    const token = document.createElement('div');
    token.className = 'player-token';
    token.dataset.userId = userId;
    token.style.backgroundColor = color;
    token.style.width = '20px';
    token.style.height = '20px';
    token.style.borderRadius = '50%';
    token.style.margin = '2px';

    let tokensContainer = cellEl.querySelector('.tokens-container');
    if (!tokensContainer) {
        tokensContainer = document.createElement('div');
        tokensContainer.className = 'tokens-container';
        tokensContainer.style.display = 'flex';
        tokensContainer.style.flexWrap = 'wrap';
        cellEl.appendChild(tokensContainer);
    }

    tokensContainer.appendChild(token);
}

function moveToken(userId, color, newCell) {
    removeToken(userId);
    createToken(userId, color, newCell);
}
//-------------------------------Tokens-------------------------------



//-------------------------------Board-------------------------------
function renderPropertyOwnership(state) {
    const props = state.properties;
    const playersData = state.players_data;
    const DJANGO_BASE = 'http://localhost:8000/';

    Object.entries(props).forEach(([cellId, prop]) => {
        const cellEl = document.querySelector(`[data-cell="${cellId}"]`);
        if (!cellEl) return;

        if (prop.skin_path) {
            const url = prop.skin_path.startsWith('http')
                ? prop.skin_path
                : DJANGO_BASE + prop.skin_path.replace(/^\/+/, '');
            cellEl.style.backgroundImage = `url(${url})`;
            cellEl.style.backgroundRepeat = 'no-repeat';
            cellEl.style.backgroundPosition = 'center';
            cellEl.style.backgroundSize = 'contain';
        }

        const owner = prop.owner;
        if (owner) {
            const ownerColor = playersData[owner]?.color;
            if (ownerColor) {
                const muted = shadeRgb(ownerColor, 0.5);
                cellEl.style.backgroundColor = muted;
            }
        }

        const houseCount = Number(prop.houses || 0);
        if (houseCount > 0) {
            addHousesToColorCardByCell(cellId, houseCount);
        }

        if (prop.mortgaged === "1") {
            const turnsLeft = Number(prop.mortgage_turns_left || 0);
            const ownerColor = (owner && playersData[owner]?.color) || "rgb(255,255,255)";
            drawLock(cellId, turnsLeft, ownerColor);
        }
    });
}

function handlePropertyBought(msg) {

    const propId = String(msg.property_id);
    if (gameState.properties[propId]) {
        gameState.properties[propId].owner = msg.new_owner;
    }

    const cellEl = document.querySelector(`[data-cell='${msg.property_id}']`);
    if (cellEl) {
        const mutedColor = shadeRgb(msg.color, 0.5);
        cellEl.style.backgroundColor = mutedColor;
    }
}

function shadeRgb(rgb, factor = 0.5) {
    const [r, g, b] = rgb.match(/\d+/g).map(Number);

    const r2 = Math.round(r * factor);
    const g2 = Math.round(g * factor);
    const b2 = Math.round(b * factor);
    return `rgb(${r2}, ${g2}, ${b2})`;
}

function handlePropertyReleased(propertyId) {
    const propIdStr = String(propertyId);

    if (gameState.properties[propIdStr]) {
        gameState.properties[propIdStr].owner = "";
    }

    const cellEl = document.querySelector(`[data-cell='${propIdStr}']`);
    if (cellEl) {
        cellEl.style.backgroundColor = "";
    }

    eraseLock(Number(propIdStr));
}
//-------------------------------Board-------------------------------


//-------------------------------END-Game-------------------------------
function handlePlayerBankrupt({ player_id, returned_properties, place, total_players }) {
    if (gameState.players_data[player_id]) {
        gameState.players_data[player_id].place = place;
    }
    gameState.players = gameState.players.filter(id => id !== player_id);

    returned_properties.forEach(propId => {
        const pid = String(propId);
        if (gameState.properties[pid]) {
            Object.assign(gameState.properties[pid], {
                owner: '',
                mortgaged: '0',
                mortgage_turns_left: '0',
                houses: '0'
            });
        }

        const cellEl = document.querySelector(`[data-cell='${pid}']`);
        if (cellEl) {
            cellEl.style.backgroundColor = '';
            const lock = cellEl.parentElement.querySelector('.mortgage-lock');
            if (lock) lock.remove();
            const builds = cellEl.parentElement.querySelectorAll('.house');
            builds.forEach(h => h.remove());
        }
    });

    removeToken(player_id);

    const block = document.querySelector(`.players-block-item[data-user-id='${player_id}']`);
    if (block) {
        block.classList.add('lost-player');
        block.style.opacity = '0.5';
        const title = block.querySelector('h1');
        if (title) title.textContent += ` (место ${place})`;
    }

    // renderPlayers(gameState);
    // renderTokens(gameState);
}
//-------------------------------END-Game-------------------------------


//---------------------------------Legend---------------------------------

function handleTurnStateUpdate(turnState, reload) {
    gameState.turn_state = turnState;

    const phase = turnState.phase;
    const currentPlayer = turnState.current_player;
    const expiresAt = Number(turnState.expires_at);
    const payload = JSON.parse(turnState.action_payload || '{}');

    isCurrentUserTurn = (currentPlayer === currentUserId);

    if (phase === 'roll_dice') {
        if (isCurrentUserTurn) {
            showRollDiceModal(expiresAt * 1000);
            if (!reload) {
                cleanActedList();
            }
        }
    }

    else if (phase === "await_purchase") {
        if (isCurrentUserTurn) {
            showPurchaseModal(payload, expiresAt * 1000);
        }
    }

    else if (phase === "await_pay_rent") {
        if (isCurrentUserTurn) {
            showRentModal(payload, expiresAt * 1000);
        }
    }

    else if (phase === "await_pay_utility") {
        if (isCurrentUserTurn) {
            showUtilityRentModal(payload, expiresAt * 1000);
        }
    }

    else if (phase === "await_pay_debt") {
        if (isCurrentUserTurn) {
            showDebtModal(payload, expiresAt * 1000);
        }
    }

    else if (phase === 'game_over') {
        showGameOverModal(payload, expiresAt * 1000);
    }
}


function formatTime(sec) {
    const m = String(Math.floor(sec / 60)).padStart(2, '0');
    const s = String(sec % 60).padStart(2, '0');
    return `${m}:${s}`;
}

function clearModalTimers(modal) {
    if (modal._modalInterval) {
        clearInterval(modal._modalInterval);
        delete modal._modalInterval;
    }
    if (modal._modalTimeout) {
        clearTimeout(modal._modalTimeout);
        delete modal._modalTimeout;
    }
}


function startModalTimer(modal, expiresAtMs, updateUI, onExpire) {
    function getRemainingSeconds() {
        return Math.max(0, Math.floor((expiresAtMs - Date.now()) / 1000));
    }

    updateUI(getRemainingSeconds());

    modal._modalInterval = setInterval(() => {
        const rem = getRemainingSeconds();
        if (rem <= 0) {
            clearModalTimers(modal);
            onExpire();
            return;
        }
        updateUI(rem);
    }, 500);

    const ttl = expiresAtMs - Date.now();
    modal._modalTimeout = setTimeout(() => {
        clearModalTimers(modal);
        onExpire();
    }, ttl + 50);
}

function bindModalCloseBehavior(modal, closeBtn, expiresAtMs, reopenBtn) {
    function getRemainingSeconds() {
        return Math.max(0, Math.floor((expiresAtMs - Date.now()) / 1000));
    }

    closeBtn.onclick = () => {
        if (modal._modalInterval) {
            clearInterval(modal._modalInterval);
            delete modal._modalInterval;
        }

        modal.style.display = 'none';

        if (getRemainingSeconds() > 0) {
            reopenBtn.style.display = 'block';
        } else {
            reopenBtn.style.display = 'none';
        }
    };
}

function showRentModal(payload, expiresAtMs) {
    const ownerId = payload.owner;
    const ownerName = payload.owner_name;
    const amount = payload.amount;

    reopenDiceModalBtn.style.display = 'none';

    clearModalTimers(diceModal);

    diceModalContent.innerHTML = `
        <h2 style="margin-bottom: 12px; color: #facc15;">Вам потрібно сплатити оренду</h2>
        <div id="rentTimer" style="font-size: 20px; margin-bottom: 10px; color: #eee;">
          ${formatTime(Math.max(0, Math.floor((expiresAtMs - Date.now()) / 1000)))}
        </div>
        <div class="dice-modal-text" style="font-size: 16px; margin-bottom: 12px; color: #fff;">
          <strong>${amount}$</strong> гравцю 
          <span style="color:#facc15; font-weight:600;">${ownerName}</span>
        </div>
        <button id="payRentBtn" class="dice-modal-button" 
                style="padding: 8px 16px; font-size: 16px;">
          Сплатити ${amount}$
        </button>
    `;

    diceModal.style.display = 'flex';

    const timerEl = diceModalContent.querySelector('#rentTimer');
    const payBtn = diceModalContent.querySelector('#payRentBtn');

    bindModalCloseBehavior(diceModal, closeDiceModalBtn, expiresAtMs, reopenDiceModalBtn);

    startModalTimer(
        diceModal,
        expiresAtMs,
        (remainingSeconds) => {
            timerEl.textContent = formatTime(remainingSeconds);
        },
        () => {
            diceModal.style.display = 'none';
            reopenDiceModalBtn.style.display = 'none';
        }
    );

    payBtn.addEventListener('click', () => {
        clearModalTimers(diceModal);

        diceModal.style.display = 'none';
        reopenDiceModalBtn.style.display = 'none';

        gameSocket.send(JSON.stringify({
            type: 'confirm_pay_rent',
            owner: ownerId,
            amount: amount
        }));
    });
}

function showRollDiceModal(expiresAtMs) {
    reopenDiceModalBtn.style.display = 'none';

    clearModalTimers(diceModal);

    diceModalContent.innerHTML = `
      <h2 style="margin-bottom: 12px; color: #facc15;">Кидок кубиків</h2>
      <div id="diceTimer" style="font-size: 20px; margin-bottom: 10px; color: #eee;">
        ${formatTime(Math.max(0, Math.floor((expiresAtMs - Date.now()) / 1000)))}
      </div>
      <div class="dice-display" style="font-size: 30px; margin-bottom: 12px; color: #fff;">
        🎲 🎲
      </div>
      <button id="rollBtn" class="dice-modal-button" 
              style="padding: 8px 16px; font-size: 16px;">
        Кинути кубики
      </button>
    `;

    diceModal.style.display = 'flex';

    const timerEl = diceModalContent.querySelector('#diceTimer');
    const diceDisplay = diceModalContent.querySelector('.dice-display');
    const rollBtn = diceModalContent.querySelector('#rollBtn');

    bindModalCloseBehavior(diceModal, closeDiceModalBtn, expiresAtMs, reopenDiceModalBtn);

    startModalTimer(
        diceModal,
        expiresAtMs,
        (remainingSeconds) => {
            timerEl.textContent = formatTime(remainingSeconds);
        },
        () => {
            diceModal.style.display = 'none';
            reopenDiceModalBtn.style.display = 'none';
        }
    );

    rollBtn.addEventListener('click', () => {
        clearModalTimers(diceModal);

        const die1 = Math.floor(Math.random() * 6) + 1;
        const die2 = Math.floor(Math.random() * 6) + 1;
        // const die1 = 39;
        // const die2 = 0;

        diceDisplay.textContent = `${die1} 🎲 ${die2}`;

        setTimeout(() => {
            diceModal.style.display = 'none';
            reopenDiceModalBtn.style.display = 'none';
            gameSocket.send(JSON.stringify({
                type: 'make_move',
                move: { dice: [die1, die2] }
            }));
        }, 1000);
    });
}


function showPurchaseModal(payload, expiresAtMs) {
    reopenDiceModalBtn.style.display = 'none';
    clearModalTimers(diceModal);

    diceModalContent.innerHTML = `
      <h2 style="margin-bottom: 12px; color: #facc15;">Купівля власності</h2>
      <div id="purchaseTimer" style="font-size: 20px; margin-bottom: 10px; color: #eee;">
        ${formatTime(Math.max(0, Math.floor((expiresAtMs - Date.now()) / 1000)))}
      </div>
      <div class="dice-modal-text" style="font-size: 16px; margin-bottom: 12px; color: #fff;">
        Ви наступили на карту компанії «<strong>${payload.property_name}</strong>»!<br>
        Придбати за <strong>${payload.price}$</strong>?
      </div>
      <div class="button-row" style="display: flex; gap: 12px; justify-content: center; margin-bottom: 12px;">
        <button id="btn-yes" class="dice-modal-button" 
                style="padding: 8px 16px; font-size: 16px;">
          Так, придбати
        </button>
        <button id="btn-no" class="dice-modal-button" 
                style="padding: 8px 16px; font-size: 16px;">
          Ні, відмовитись
        </button>
      </div>
      <button id="btn-info" class="dice-modal-button" 
              style="padding: 6px 12px; font-size: 14px;">
        Інформація про компанію
      </button>
    `;

    diceModal.style.display = 'flex';

    const timerEl = diceModalContent.querySelector('#purchaseTimer');
    const yesBtn = diceModalContent.querySelector('#btn-yes');
    const noBtn = diceModalContent.querySelector('#btn-no');
    const infoBtn = diceModalContent.querySelector('#btn-info');

    bindModalCloseBehavior(diceModal, closeDiceModalBtn, expiresAtMs, reopenDiceModalBtn);

    startModalTimer(
        diceModal,
        expiresAtMs,
        (remainingSeconds) => {
            timerEl.textContent = formatTime(remainingSeconds);
        },
        () => {
            diceModal.style.display = 'none';
            reopenDiceModalBtn.style.display = 'none';
        }
    );

    yesBtn.addEventListener('click', () => {
        clearModalTimers(diceModal);
        diceModal.style.display = 'none';
        reopenDiceModalBtn.style.display = 'none';

        gameSocket.send(JSON.stringify({
            type: 'confirm_buy',
            property_id: payload.property_id,
            property_name: payload.property_name
        }));
    });

    noBtn.addEventListener('click', () => {
        clearModalTimers(diceModal);
        diceModal.style.display = 'none';
        reopenDiceModalBtn.style.display = 'none';

        gameSocket.send(JSON.stringify({
            type: 'decline_buy',
            property_id: payload.property_id,
            property_name: payload.property_name
        }));
    });

    infoBtn.addEventListener('click', () => {
        showPropertyModal(payload.property_id);
    });
}

function showUtilityRentModal(payload, expiresAtMs) {
    clearModalTimers(diceModal);
    reopenDiceModalBtn.style.display = 'none';

    const initialSec = Math.max(0, Math.floor((expiresAtMs - Date.now()) / 1000));
    diceModalContent.innerHTML = `
      <h2 style="margin-bottom:12px; color:#facc15;">
        Киньте кубики для розрахунку оренди (×${payload.multiplier})
      </h2>
      <div id="utilTimer" style="font-size:20px; margin-bottom:10px; color:#eee;">
        ${formatTime(initialSec)}
      </div>
      <div class="dice-display" style="font-size:30px; margin-bottom:12px; color:#fff;">
        🎲 🎲
      </div>
      <button id="utilRollBtn" class="dice-modal-button" 
              style="padding:8px 16px; font-size:16px;">
        Кинути
      </button>
    `;
    diceModal.style.display = 'flex';

    const timerEl = diceModalContent.querySelector('#utilTimer');
    const rollBtn = diceModalContent.querySelector('#utilRollBtn');

    bindModalCloseBehavior(diceModal, closeDiceModalBtn, expiresAtMs, reopenDiceModalBtn);

    startModalTimer(
        diceModal,
        expiresAtMs,
        (remainingSeconds) => {
            timerEl.textContent = formatTime(remainingSeconds);
        },
        () => {
            diceModal.style.display = 'none';
            reopenDiceModalBtn.style.display = 'none';
        }
    );

    rollBtn.addEventListener('click', () => {
        clearModalTimers(diceModal);

        const die1 = Math.floor(Math.random() * 6) + 1;
        const die2 = Math.floor(Math.random() * 6) + 1;
        sum = die1 + die2;
        total = sum * payload.multiplier;

        gameSocket.send(JSON.stringify({
            type: 'confirm_pay_utility',
            owner: payload.owner,
            dice: [die1, die2],
            multiplier: payload.multiplier
        }));

        diceModalContent.innerHTML = `
        <h2 style="margin-bottom:12px; color:#facc15;">
          Ви кинули кубики!
        </h2>
        <div class="dice-display" 
             style="font-size:30px; margin-bottom:12px; color:#fff;">
          ${die1} 🎲 + 🎲 ${die2} → <strong>${sum}</strong>
        </div>
        <div style="font-size:18px; margin-bottom:12px; color:#eee;">
          Рента: ${sum} × ${payload.multiplier} = <strong>${total}$</strong>
          гравцю 
          <span style="color:#facc15; font-weight:600;">
            ${payload.owner_name}
          </span>
        </div>
      `;

        closeDiceModalBtn.onclick = () => {
            diceModal.style.display = 'none';
            reopenDiceModalBtn.style.display = 'none';
        };

        setTimeout(() => {
            diceModal.style.display = 'none';
            reopenDiceModalBtn.style.display = 'none';
        }, 3000);
    });
}

function showMessageModal(message) {
    reopenDiceModalBtn.style.display = 'none';
    clearModalTimers(diceModal);

    diceModalContent.innerHTML = `
      <h2 style="margin-bottom: 12px; color: #facc15;">Увага!</h2>
      <div class="dice-modal-text" style="font-size:16px; color:#fff; margin-bottom: 12px;">
        ${message}
      </div>
      <button id="messageOkBtn" class="dice-modal-button" 
              style="padding:8px 16px; font-size:16px;">
        Ок
      </button>
    `;

    diceModal.style.display = 'flex';

    const okBtn = document.getElementById('messageOkBtn');
    okBtn.addEventListener('click', () => {
        diceModal.style.display = 'none';
    });

    closeDiceModalBtn.onclick = () => {
        diceModal.style.display = 'none';
    };
}

function showDebtModal(payload, expiresAtMs) {
    const {
        creditorId,
        creditorName,
        currentCash,
        totalAssets,
        totalOwed
    } = payload;

    reopenDiceModalBtn.style.display = 'none';

    clearModalTimers(diceModal);

    const actualBalance = gameState.players_data[currentUserId].balance;
    const alreadyReceived = Math.max(0, actualBalance - currentCash);

    const initialShortfall = Math.max(0, totalOwed - currentCash);

    diceModalContent.innerHTML = `
      <h2 style="margin-bottom:12px; color:#facc15;">Сплатити борг</h2>
      <div id="debtTimer" style="font-size:20px; margin-bottom:10px; color:#eee;">
        ${formatTime(Math.max(0, Math.floor((expiresAtMs - Date.now()) / 1000)))}
      </div>
      <div class="dice-modal-text" style="font-size:16px; margin-bottom:8px; color:#fff;">
        Подіяні кошти: 
        <strong>
          <span id="debtReceived">${alreadyReceived}</span>$ /
          <span id="debtShortfall">${initialShortfall}</span>$
        </strong>
      </div>
      <div class="dice-modal-text" style="font-size:16px; margin-bottom:8px; color:#fff;">
        Потенційні активи: <strong>${totalAssets}$</strong>
      </div>
      <div class="dice-modal-text" style="font-size:16px; margin-bottom:12px; color:#fff;">
        Потрібно сплатити: <strong>${totalOwed}$</strong> гравцю 
        <span style="color:#facc15; font-weight:600;">${creditorName}</span>
      </div>
      <button id="payDebtBtn" class="dice-modal-button" 
              style="padding:8px 16px; font-size:16px; opacity: 0.4; cursor: not-allowed" disabled>
        Сплатити ${totalOwed}$
      </button>
    `;

    diceModal.style.display = 'flex';

    const timerEl = diceModalContent.querySelector('#debtTimer');
    const payBtn = diceModalContent.querySelector('#payDebtBtn');

    bindModalCloseBehavior(diceModal, closeDiceModalBtn, expiresAtMs, reopenDiceModalBtn);

    startModalTimer(
        diceModal,
        expiresAtMs,
        (remainingSeconds) => {
            timerEl.textContent = formatTime(remainingSeconds);
        },
        () => {
            diceModal.style.display = 'none';
            reopenDiceModalBtn.style.display = 'none';
        }
    );

    if (actualBalance >= totalOwed) {
        payBtn.disabled = false;
        payBtn.style.opacity = '';
        payBtn.style.cursor = '';
    }

    payBtn.addEventListener('click', () => {
        clearModalTimers(diceModal);

        diceModal.style.display = 'none';
        reopenDiceModalBtn.style.display = 'none';

        gameSocket.send(JSON.stringify({
            type: 'confirm_pay_debt',
            creditor: creditorId,
            amount: totalOwed
        }));
    });
}

function showGameOverModal(payload, expiresAtMs) {
    clearModalTimers(diceModal);
    reopenDiceModalBtn.style.display = 'none';

    const startTs = new Date(gameState.meta.created_at).getTime();
    const durationSec = Math.floor((Date.now() - startTs) / 1000);
    const formattedDuration = formatTime(durationSec);

    const medals = { '1': '🥇', '2': '🥈', '3': '🥉' };
    let listHtml = '<ol style="padding-left:20px;">';
    for (let pos of ['1', '2', '3', '4']) {
        const uid = payload.rankings[pos];
        if (!uid) continue;
        const pdata = gameState.players_data[uid] || {};
        const name = pdata.username || 'Игрок';
        const color = pdata.color || '#ccc';
        const medal = medals[pos] || '';
        listHtml += `
            <li style="margin-bottom:8px; display:flex; align-items:center;">
                <span style="font-size:24px; margin-right:8px;">${medal}</span>
                <span style="flex:1; color:${color};">${name}</span>
                <span style="margin-left:8px;">
                  ${pos} место
                </span>
            </li>`;
    }
    listHtml += '</ol>';

    diceModalContent.innerHTML = `
        <h2 style="color:#facc15; margin-bottom:12px;">Игра окончена!</h2>
        <div style="font-size:16px; color:#fff; margin-bottom:10px;">
          Длительность игры: <strong>${formattedDuration}</strong>
        </div>
        <div style="font-size:16px; color:#fff; margin-bottom:12px;">
          Итоговый рейтинг:
        </div>
        ${listHtml}
        <div id="gameOverTimer" style="font-size:20px; color:#eee; margin-top:12px;"></div>
        <button id="gameOverHomeBtn" class="dice-modal-button" style="margin-top:12px;">
          На главную
        </button>
    `;
    diceModal.style.display = 'flex';

    const timerEl = diceModalContent.querySelector('#gameOverTimer');
    const homeBtn = diceModalContent.querySelector('#gameOverHomeBtn');

    bindModalCloseBehavior(diceModal, closeDiceModalBtn, expiresAtMs, reopenDiceModalBtn);
    startModalTimer(
        diceModal,
        expiresAtMs,
        remaining => timerEl.textContent = `Автовыход через ${formatTime(remaining)}`,
        () => window.location.href = '/'
    );

    homeBtn.onclick = () => window.location.href = '/';
}


reopenDiceModalBtn.addEventListener('click', () => {
    const ts = gameState.turn_state;
    if (!ts) return;

    const phase = ts.phase;
    const currentPlayer = ts.current_player;
    const expiresAtMs = Number(ts.expires_at) * 1000;
    const payload = JSON.parse(ts.action_payload || '{}');

    if (currentPlayer !== currentUserId) {
        return;
    }

    switch (phase) {
        case 'roll_dice':
            showRollDiceModal(expiresAtMs);
            break;
        case 'await_purchase':
            showPurchaseModal(payload, expiresAtMs);
            break;
        case 'await_pay_rent':
            showRentModal(payload, expiresAtMs);
            break;
        case 'await_pay_utility':
            showUtilityRentModal(payload, expiresAtMs);
            break;
        case 'await_pay_debt':
            showDebtModal(payload, expiresAtMs);
        case 'game_over':
            showGameOverModal(payload, expiresAtMs);

        default:
            return;
    }
    reopenDiceModalBtn.style.display = 'none';
});


