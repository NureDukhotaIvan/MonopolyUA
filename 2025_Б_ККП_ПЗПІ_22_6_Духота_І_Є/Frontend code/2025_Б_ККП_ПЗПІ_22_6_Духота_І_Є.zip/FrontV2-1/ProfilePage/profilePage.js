//---Всі дії над профілем---
document.addEventListener("DOMContentLoaded", () => {

    const token = localStorage.getItem("authToken");
    const nameInput = document.getElementById("nameInput");
    const regionInput = document.getElementById("regionInput");
    const passInput = document.getElementById("passInput");
    const repeatPassInput = document.getElementById("repeatPassInput");
    const avatar = document.getElementById("avatar");
    const editBtn = document.getElementById("acceptChange");
    const cancelBtn = document.getElementById("cancelChange");

    let editing = false;
    let originalName = "";
    let originalRegion = "";

    function applyDisabledStyles() {
        [nameInput, regionInput].forEach(input => {
            input.style.cursor = "default";
            input.classList.add("no-hover");
        });
    }

    function removeDisabledStyles() {
        [nameInput, regionInput].forEach(input => {
            input.style.cursor = "text";
            input.classList.remove("no-hover");
        });
    }

    fetch("http://localhost:8000/profile/info/", {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
        }
    })
        .then(response => response.json())
        .then(data => {
            avatar.src = data.avatar;
            nameInput.value = data.username;

            if (data.region) {
                const optionExists = Array.from(regionInput.options).some(
                    option => option.value === data.region
                );
                if (optionExists) {
                    regionInput.value = data.region;
                } else {
                    regionInput.value = "";
                }
            } else {
                regionInput.value = "";
            }

            originalName = data.username;
            originalRegion = regionInput.value;

            nameInput.disabled = true;
            regionInput.disabled = true;
            applyDisabledStyles();
        })
        .catch(err => {
            console.error("Помилка отримання профілю:", err);
            alert("Не вдалося завантажити профіль");
        });


    fetch("http://localhost:8000/profile/stat/", {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + localStorage.getItem("authToken"),
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error("Не вдалося отримати статистику");
            }
            return response.json();
        })
        .then(data => {
            document.getElementById("stat-games").textContent = data.games;
            document.getElementById("stat-wins").textContent = data.wins;
            document.getElementById("stat-loses").textContent = data.lose;
            document.getElementById("stat-percentage").textContent = data.percentage + "%";
            document.getElementById("stat-points").textContent = data.points;
        })
        .catch(error => {
            console.error("Помилка при завантаженні статистики:", error);
        });

    editBtn.addEventListener("click", () => {
        if (!editing) {
            editing = true;
            nameInput.disabled = false;
            regionInput.disabled = false;

            removeDisabledStyles();

            passInput.style.opacity = "1";
            repeatPassInput.style.opacity = "1";
            passInput.style.pointerEvents = "auto";
            repeatPassInput.style.pointerEvents = "auto";

            cancelBtn.style.opacity = "1";
            cancelBtn.style.pointerEvents = "auto";

            editBtn.textContent = "Зберегти";
        } else {
            if (passInput.value !== repeatPassInput.value) {
                alert("Паролі не співпадають!");
                return;
            }

            fetch("http://localhost:8000/profile/update/", {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify({
                    username: nameInput.value,
                    region: regionInput.value,
                    password: passInput.value || undefined
                })
            })
                .then(response => {
                    if (!response.ok) throw new Error("Заповніть всі необхідні поля");
                    return response.json();
                })
                .then(data => {
                    nameInput.disabled = true;
                    regionInput.disabled = true;
                    applyDisabledStyles();

                    passInput.style.opacity = "0";
                    repeatPassInput.style.opacity = "0";
                    passInput.style.pointerEvents = "none";
                    repeatPassInput.style.pointerEvents = "none";

                    cancelBtn.style.opacity = "0";
                    cancelBtn.style.pointerEvents = "none";

                    editBtn.textContent = "Редагувати";
                    editing = false;

                    originalName = data.username;
                    originalRegion = data.region || "";

                    alert("Профіль оновлено");
                })
                .catch(error => {
                    alert(error.message);
                });
        }
    });

    cancelBtn.addEventListener("click", () => {
        nameInput.value = originalName;
        regionInput.value = originalRegion;

        nameInput.disabled = true;
        regionInput.disabled = true;
        applyDisabledStyles();

        passInput.value = "";
        repeatPassInput.value = "";

        passInput.style.opacity = "0";
        repeatPassInput.style.opacity = "0";
        passInput.style.pointerEvents = "none";
        repeatPassInput.style.pointerEvents = "none";

        cancelBtn.style.opacity = "0";
        cancelBtn.style.pointerEvents = "none";

        editBtn.textContent = "Редагувати";
        editing = false;
    });

    document.getElementById("changePictureBtn").addEventListener("click", function () {
        document.getElementById("uploadInput").click();
    });

    document.getElementById("uploadInput").addEventListener("change", function () {
        const file = this.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append("avatar", file);

        fetch("http://localhost:8000/profile/avatar/", {
            method: "PATCH",
            headers: {
                Authorization: `Bearer ${localStorage.getItem("authToken")}`
            },
            body: formData
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Не вдалося оновити фото");
                }
                return response.json();
            })
            .then(data => {
                document.getElementById("avatar").src = data.avatar;
            })
            .catch(error => {
                console.log(error.message);
            });
    });
});
//---Всі дії над профілем---

//---Список друзів та їх видалення---
const friends = [];
const token = localStorage.getItem('authToken');
fetch('http://localhost:8000/friends/user-friends/', {
    method: 'GET',
    headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    }
})
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        return response.json();
    })
    .then(data => {
        console.log("Friends:", data);

        data.forEach(friend => {
            friends.push(friend);
        });
        renderFriends(currentPage);

        console.log("Friends array:", friends);
    })
    .catch(error => {
        console.error('Error:', error);
    });

const friendsListMid = document.querySelector('.friends-list-mid');
const friendsListBot = document.querySelector('.friends-list-bot');

const itemsPerPage = 9;
let currentPage = 1;

function renderFriends(page) {
    friendsListMid.innerHTML = '';
    const start = (page - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const pageFriends = friends.slice(start, end);

    pageFriends.forEach((friend, index) => {
        const friendItem = document.createElement('div');
        friendItem.className = 'friend-item';

        friendItem.innerHTML = `
          <span>${friend.username}</span>
          <button class="remove-friend-btn" onclick="removeFriend(${start + index}, ${friend.id})">Видалити</button>
      `;

        friendsListMid.appendChild(friendItem);
    });
}

function renderPagination() {
    friendsListBot.innerHTML = '';
    const pageCount = Math.ceil(friends.length / itemsPerPage);

    for (let i = 1; i <= pageCount; i++) {
        const pageBtn = document.createElement('span');
        pageBtn.className = 'page-num' + (i === currentPage ? ' active' : '');
        pageBtn.innerText = i;
        pageBtn.addEventListener('click', () => {
            currentPage = i;
            renderFriends(currentPage);
            renderPagination();
        });
        friendsListBot.appendChild(pageBtn);
    }
}

function removeFriend(index, id) {
    const confirmed = confirm("Ви впевнені, що хочете видалити цього друга?");
    if (!confirmed) return;

    const token = localStorage.getItem('authToken');

    fetch('http://localhost:8000/friends/delete-friend/', {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ friend_id: id })
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Не вдалося видалити друга.');
            }
            friends.splice(index, 1);
            if (currentPage > Math.ceil(friends.length / itemsPerPage)) {
                currentPage--;
            }
            renderFriends(currentPage);
            renderPagination();
        })
        .catch(error => {
            console.error('Помилка при видаленні:', error);
            alert('Сталася помилка при видаленні друга.');
        });
}

renderFriends(currentPage);
renderPagination();
//---Список друзів та їх видалення---

//---Секція інвентарю---
const cubesBtn = document.getElementById('cubesBtn');
const cardsBtn = document.getElementById('cardsBtn');
const casesBtn = document.getElementById('casesBtn');
const inventorySection = document.querySelector('.player-inventory-data');

let currentType = 'dice';

function clearActiveButtons() {
    document.querySelectorAll('.type-buttons').forEach(btn => btn.classList.remove('active'));
}

async function renderItems(type) {
    inventorySection.innerHTML = '';
    try {
        const response = await fetch(`http://localhost:8000/market/user-inventory/?category=${type}`, {
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('authToken')
            }
        });

        if (!response.ok) throw new Error('Не вдалося завантажити інвентар.');
        const items = await response.json();
        let openMenu = null;

        items.forEach(itemData => {
            const item = document.createElement('div');
            item.className = 'item';
            item.dataset.id = itemData.item.id;
            item.dataset.type = itemData.item.category;

            item.innerHTML = `
                <div class="item-header">
                    <div class="item-title">${itemData.item.name}</div>
                    <button class="menu-button" title="Меню">&#8942;</button>
                    <div class="item-info">
                        <p class="rarirty">Рідкість: ${itemData.item.rarity}</p>
                        <p class="quantity">Кількість: ${itemData.quantity}</p>
                    </div>
                </div>
                <img src="${itemData.item.image}" alt="${itemData.item.name}">
            `;

            const menuBtn = item.querySelector('.menu-button');
            let optionsMenu = null;

            menuBtn.addEventListener('click', (e) => {
                e.stopPropagation();

                if (optionsMenu) {
                    optionsMenu.remove();
                    optionsMenu = null;
                    openMenu = null;
                    return;
                }

                if (openMenu && openMenu !== item) {
                    const prevMenu = openMenu.querySelector('.options-menu-inv');
                    if (prevMenu) prevMenu.remove();
                    openMenu = null;
                }

                optionsMenu = document.createElement('div');
                optionsMenu.className = 'options-menu-inv';

                let buttons = [];
                switch (itemData.item.category?.toLowerCase()) {
                    case 'кубик':
                        buttons = ['Обрати', 'Продати'];
                        break;
                    case 'карта':
                        buttons = ['Обрати', 'Продати'];
                        break;
                    case 'кейс':
                        buttons = ['Відкрити', 'Продати'];
                        break;
                }

                buttons.forEach(text => {
                    const btn = document.createElement('button');
                    btn.textContent = text;
                    optionsMenu.appendChild(btn);

                    btn.addEventListener('click', async () => {
                        console.log(`${text} clicked on item id=${itemData.item.id}`);
                        itemId = itemData.item.id;

                        if (text === 'Продати') {
                            modal.dataset.id = itemId;
                            openSellModal(itemId)
                        }
                        else if (text === 'Відкрити') {
                            window.location.href = `../CaseOpeningPage/caseOpeningPage.html?case_id=${itemId}`;

                        }

                        optionsMenu.remove();
                        optionsMenu = null;
                        openMenu = null;
                    });
                });

                item.appendChild(optionsMenu);
                openMenu = item;
            });

            inventorySection.appendChild(item);
        });

        document.addEventListener('click', () => {
            if (openMenu) {
                const menu = openMenu.querySelector('.options-menu-inv');
                if (menu) menu.remove();
                openMenu = null;
            }
        });
    } catch (error) {
        console.error('Помилка при завантаженні інвентарю:', error);
    }
}

cubesBtn.addEventListener('click', () => {
    clearActiveButtons();
    cubesBtn.classList.add('active');
    currentType = 'dice';
    renderItems(currentType);
});

cardsBtn.addEventListener('click', () => {
    clearActiveButtons();
    cardsBtn.classList.add('active');
    currentType = 'card';
    renderItems(currentType);
});

casesBtn.addEventListener('click', () => {
    clearActiveButtons();
    casesBtn.classList.add('active');
    currentType = 'case';
    renderItems(currentType);
});

renderItems(currentType);

const modal = document.getElementById('modal');
const closeBtn = modal.querySelector('.close');
const modalContent = modal.querySelector('.modal-content');
const sellBtn = document.getElementById('sell-button');
const modalTitle = document.getElementById('modal-title');

closeBtn.addEventListener('click', (event) => {
    event.stopPropagation();
    modal.classList.add('hidden');
});

if (modalContent) {
    modalContent.addEventListener('click', (e) => {
        e.stopPropagation();
    });
}

async function openSellModal(itemId) {
    modal.classList.remove('hidden');
    try {
        const response = await fetch(`http://localhost:8000/market/item/${itemId}`, {
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('authToken')
            }
        });

        const data = await response.json();
        console.log(data);
        modalTitle.textContent = `Продати ${data.item.name}`;
    } catch (err) {
        console.error(err);
        modalTitle.textContent = `Продати товар`;
    }
}

sellBtn.addEventListener('click', async () => {
    const itemId = modal.dataset.id;
    const costValue = modal.querySelector('.cost-item').value.trim();
    const amountValue = modal.querySelector('.amount-item').value.trim();

    if (!costValue || !amountValue) {
        alert('Будь ласка, заповніть усі поля.');
        return;
    }

    const cost = parseInt(costValue);
    const amount = parseInt(amountValue);

    if (isNaN(cost) || cost <= 0) {
        alert('Вкажіть коректну ціну більше 0.');
        return;
    }

    if (isNaN(amount) || amount <= 0) {
        alert('Вкажіть коректну кількість більше 0.');
        return;
    }

    try {
        const response = await fetch(`http://localhost:8000/market/item/sell/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + localStorage.getItem('authToken')
            },
            body: JSON.stringify({
                item_id: parseInt(itemId),
                price: cost,
                quantity: amount
            })
        });

        const result = await response.json();
        if (!response.ok) {
            alert(result.message);
            throw new Error('Помилка при продажу товару');
        }
        alert(result.message);

        modal.classList.add('hidden');
        renderItems(currentType);
    } catch (err) {
        console.error('Продаж не вдався:', err);
    }
});
//---Секція інвентарю---