document.addEventListener('DOMContentLoaded', () => {
  const burgerBtn = document.querySelector('.burger-btn');
  const sidebar = document.querySelector('.sidebar');
  const closeBtn = document.querySelector('.close-btn');
  const overlay = document.querySelector('.overlay');
  const logoutBtn = document.querySelector('.logout-btn'); 

  if (burgerBtn && sidebar && closeBtn && overlay) {
    burgerBtn.addEventListener('click', () => {
      sidebar.classList.add('open');
      overlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    });

    closeBtn.addEventListener('click', () => {
      sidebar.classList.remove('open');
      overlay.classList.remove('active');
      document.body.style.overflow = '';
    });
  }

  const scrollBtn = document.querySelector('.scroll-to-rules');
  const rulesContainer = document.querySelector('.container-rules');

  if (scrollBtn && rulesContainer) {
    scrollBtn.addEventListener('click', function (e) {
      e.preventDefault();
      rulesContainer.scrollIntoView({
        behavior: 'smooth'
      });
    });
  }

  const token = localStorage.getItem('authToken'); 
  const gameCurrencyElement = document.getElementById('user-balance'); 

  if (token && gameCurrencyElement) {
    fetch('http://localhost:8000/profile/info/', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      }
    })
    .then(response => response.json())
    .then(data => {
      const gameCurrency = data.game_currency;
      if (gameCurrency !== undefined) {
        gameCurrencyElement.textContent = `${gameCurrency}`;
      }
    })
    .catch(error => {
      console.error('Помилка при отриманні інформації про користувача:', error);
    });
  }

  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      const confirmLogout = window.confirm("Ви точно хочете вийти?");
      if (confirmLogout) {
        localStorage.removeItem('authToken');
        window.location.replace('../Registration/registration.html');
      }
    });
  }

  loadNotifications();
});

function createNotificationItem(notification) {
  const item = document.createElement('div');
  item.classList.add('notification-item');
  item.dataset.id = notification.id;

  item.innerHTML = `
    <span>${notification.message || 'Нове сповіщення від ' + notification.sender_username}</span>
    <button class="options-btn">⋮</button>
    <div class="options-menu">
      <button class="accept">Прийняти</button>
      <button class="decline">Відмінити</button>
    </div>
  `;

  return item;
}

function loadNotifications() {
  const token = localStorage.getItem('authToken');
  const list = document.getElementById('notifications-list');

  if (!token || !list) return;

  fetch('http://localhost:8000/notifications/', {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    }
  })
  .then(res => res.json())
  .then(data => {
    list.innerHTML = ''; 
    data.forEach(notification => {
      const item = createNotificationItem(notification);
      list.appendChild(item);
    });
  })
  .catch(err => {
    console.error('Помилка при завантаженні сповіщень:', err);
  });
}

document.addEventListener('click', (e) => {
  const target = e.target;

  if (target.classList.contains('options-btn')) {
    e.stopPropagation();
    const notification = target.closest('.notification-item');
    document.querySelectorAll('.notification-item').forEach(n => {
      if (n !== notification) n.classList.remove('show-options');
    });
    notification.classList.toggle('show-options');
    return;
  }

  if (target.classList.contains('accept') || target.classList.contains('decline')) {
    const isAccept = target.classList.contains('accept');
    const notificationItem = target.closest('.notification-item');
    const id = notificationItem?.dataset.id;
    const token = localStorage.getItem('authToken');

    if (!id || !token) return;

    const url = `http://localhost:8000/notifications/manage/${id}/`;

    fetch(url, {
      method: isAccept ? 'POST' : 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    })
    .then(res => {
      if (res.ok) {
        notificationItem.remove(); 
        alert(`${isAccept ? 'Було додано друга' : 'Запрошення відмінено'}`)
        location.reload();
      } else {
        console.error(`Не вдалося ${isAccept ? 'прийняти' : 'відхилити'} сповіщення`);
      }

    })
    .catch(err => console.error('Помилка при відповіді на сповіщення:', err));

    return;
  }

  document.querySelectorAll('.notification-item').forEach(notification => {
    if (!notification.contains(target)) {
      notification.classList.remove('show-options');
    }
  });
});
