let currentUserId = null;
let inLobby = false;

//-------------------------------Elements-------------------------------
const playersSelect = document.getElementById('playersAmount');
const createBtn = document.getElementById('lobbyCreateBtn');
const regionSelect = document.getElementById('regionPick');
const lobbyNameInput = document.getElementById('lobbyNameInput');
const lobbyBlock = document.querySelector('.game-create-lobby');
const lobbyNameHeader = document.getElementById('lobbyNameHeader');
const deleteBtn = document.getElementById('lobbyDeleteBtn');
const lobbyMid = document.querySelector('.game-create-lobby-mid');
const startBtn = lobbyBlock.querySelector('.start-game');
const closedLobbySelector = document.getElementById('closedLobby');
const startSearchBtn = document.getElementById('startRatingGameSearch');
const stopSearchBtn = document.getElementById('stopSearchGame');
const searchContainer = document.querySelector('.rating-game-search');
const timerDisplay = document.getElementById('searchTimer');
const lobbyListContainer = document.querySelector('.lobbygames-list');

//-------------------------------CreateLobby-------------------------------
function validateForm() {
    const missing = [];

    if (!lobbyNameInput.value.trim()) {
        lobbyNameInput.style.border = '1px solid red';
        missing.push('Назва');
    } else {
        lobbyNameInput.style.border = '';
    }

    if (regionSelect.value === 'empty') {
        regionSelect.style.border = '1px solid red';
        missing.push('Регіон');
    } else {
        regionSelect.style.border = '';
    }

    if (playersSelect.value === 'empty') {
        playersSelect.style.border = '1px solid red';
        missing.push('Кількість гравців');
    } else {
        playersSelect.style.border = '';
    }

    if (missing.length > 0) {
        alert(`⚠️ Заповніть поля: (${missing.join(', ')})`);
        return false;
    }

    return true;
}


createBtn.addEventListener('click', () => {

    if (!validateForm()) return;

    const payload = {
        name: lobbyNameInput.value.trim(),
        region: regionSelect.value,
        max_players: parseInt(playersSelect.value, 10),
        invite_only: closedLobbySelector.checked,
    };
    createLobby(payload);
});


document.addEventListener('DOMContentLoaded', function () {
    initPage();
});


//-------------------------initPage-------------------------
async function initPage() {
    try {
        await fetchMe();

        setupUIHandlers();
        initLobbyWebSocket();
        fetchUserRank();

    } catch (err) {
        console.error('Не смогли получить профиль:', err);
        window.location.href = '/login.html';
    }
}
//-------------------------initPage-------------------------


//-------------------------WSL-------------------------
function initLobbyWebSocket() {
    const token = localStorage.getItem('authToken');
    const wsProtocol = window.location.protocol === 'https:' ? 'wss' : 'ws';

    const wsUrl = `${wsProtocol}://localhost:8000/ws/lobbies/?token=${token}`;
    const lobbySocket = new WebSocket(wsUrl);

    lobbySocket.addEventListener('open', () => {
        console.log('WebSocket connected');
        // alert('WebSocket connected');
    });

    lobbySocket.addEventListener('message', (evt) => {
        const msg = JSON.parse(evt.data);
        if (msg.type === 'init') {
            renderLobbyList(msg.lobbies);
        }
        else if (msg.type === 'lobby_start') {
            // alert("start")
            const sessionId = msg.session_id;
            window.location.href = `/board/lobby.html?session=${sessionId}`;
        }
        else {
            // msg.action = 'create'|'update'|'remove'
            handleLobbyEvent(msg.data);
        }
    });

    lobbySocket.addEventListener('close', () => {
        console.log('WebSocket disconnected, retry in 1s');
        // alert('WebSocket disconnected, retry in 1s');
        setTimeout(() => initLobbyWebSocket(), 1000);
    });
}
//-------------------------WSL-------------------------


//-------------------------Handlers-------------------------
function setupUIHandlers() {

    let timerInterval;
    let secondsElapsed = 0;

    function formatTime(sec) {
        const minutes = Math.floor(sec / 60).toString().padStart(2, '0');
        const seconds = (sec % 60).toString().padStart(2, '0');
        return `${minutes}:${seconds}`;
    }

    function startTimer() {
        secondsElapsed = 0;
        timerDisplay.textContent = formatTime(secondsElapsed);
        timerInterval = setInterval(() => {
            secondsElapsed++;
            timerDisplay.textContent = formatTime(secondsElapsed);
        }, 1000);
    }

    function stopTimer() {
        clearInterval(timerInterval);
    }

    startSearchBtn.addEventListener('click', () => {
        searchContainer.style.opacity = '1';
        searchContainer.style.pointerEvents = 'auto';
        startTimer();

        startSearchBtn.disabled = true;
        startSearchBtn.style.opacity = '0.5';
        startSearchBtn.style.cursor = 'not-allowed';

        createBtn.disabled = true;
        createBtn.style.opacity = '0.5';
        createBtn.style.cursor = 'not-allowed';

        playersSelect.disabled = true;
        playersSelect.style.opacity = '0.5';
        playersSelect.style.cursor = 'not-allowed';

        regionSelect.disabled = true;
        regionSelect.style.opacity = '0.5';
        regionSelect.style.cursor = 'not-allowed';

        lobbyNameInput.disabled = true;
        lobbyNameInput.style.opacity = '0.5';
        lobbyNameInput.style.cursor = 'not-allowed';

        closedLobbySelector.disabled = true;
        closedLobbySelector.style.opacity = '0.5';
        closedLobbySelector.style.cursor = 'not-allowed';
    });

    stopSearchBtn.addEventListener('click', () => {
        const confirmed = confirm('Ви впевнені, що хочете припинити пошук?');
        if (confirmed) {
            searchContainer.style.opacity = '0';
            searchContainer.style.pointerEvents = 'none';
            stopTimer();

            startSearchBtn.disabled = false;
            startSearchBtn.style.opacity = '1';
            startSearchBtn.style.cursor = 'pointer';

            createBtn.disabled = false;
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';

            playersSelect.disabled = false;
            playersSelect.style.opacity = '1';
            playersSelect.style.cursor = 'pointer';

            regionSelect.disabled = false;
            regionSelect.style.opacity = '1';
            regionSelect.style.cursor = 'pointer';

            lobbyNameInput.disabled = false;
            lobbyNameInput.style.opacity = '1';
            lobbyNameInput.style.cursor = 'pointer';

            closedLobbySelector.disabled = false;
            closedLobbySelector.style.opacity = '1';
            closedLobbySelector.style.cursor = 'pointer';
        }
    });
}
//-------------------------Handlers-------------------------


//-------------------------LobbyRendering-------------------------

async function renderLobbyList(lobbies) {

    lobbyListContainer.innerHTML = '';

    for (const lobby of lobbies) {
        if (lobby.players.includes(String(currentUserId))) {
            await renderMyLobby(lobby);
        } else {
            await addOrUpdateLobby(lobby);
        }
    }
}

function handleLobbyEvent(msg) {
    const { action, lobby, id, players, remove_player } = msg;
    listOfPlayers = players ? players : lobby.players;

    isMyLobby = listOfPlayers.includes(String(currentUserId));

    if (action === 'create' || action === 'update') {
        if (isMyLobby) {
            renderMyLobby(lobby);
        } else {
            addOrUpdateLobby(lobby);
        }
    }
    else if (action === 'remove') {
        if (isMyLobby) {
            enableMainControls();
            inLobby = false;
        }
        else {
            const el = document.getElementById('lobby-' + id);
            if (el) el.remove();
        }
    }
    else if (action === 'kick') {
        if (isMyLobby) {
            renderMyLobby(lobby);
        }
        else if (String(currentUserId) == remove_player) {
            alert("Вас вигнали з лобі");
            addOrUpdateLobby(lobby);
            enableMainControls();
            inLobby = false;
        }
        else {
            addOrUpdateLobby(lobby);
        }
    }
}


async function addOrUpdateLobby(lobby) {
    if (lobby.invite_only == true) {
        return;
    }

    let el = document.getElementById('lobby-' + lobby.id);
    if (!el) {
        el = document.createElement('div');
        el.className = 'lobby-item';
        el.id = 'lobby-' + lobby.id;
        lobbyListContainer.appendChild(el);
    }

    const playersProfiles = await Promise.all(
        lobby.players.map(id => fetchUserProfile(id))
    );

    const creatorId = lobby.creator;
    const idx = playersProfiles.findIndex(p => p.id === creatorId);
    if (idx > 0) {
        const [creator] = playersProfiles.splice(idx, 1);
        playersProfiles.unshift(creator);
    }

    let slotsHtml = '';

    for (let i = 0; i < lobby.max_players; i++) {
        if (i < playersProfiles.length) {
            const player = playersProfiles[i];
            const specialClass = i === 0 ? 'creator-slot' : '';
            slotsHtml += `
                <div class="user-slot ${specialClass}">
                    <img src="${player.avatar}" alt="${player.username}" class="player-avatar" />
                </div>`;
        } else {
            slotsHtml += `<div class="user-slot"></div>`;
        }
    }
    el.innerHTML = `
    <div class="lobby-item-top">
        <h1>${lobby.name}</h1>
    </div>
    <div class="lobby-item-bot">
      <div class="lobby-item-bot-left">
        ${slotsHtml}
        <p>${lobby.players_count}/${lobby.max_players}</p>
      </div>
      <div class="lobby-item-bot-right">
        <button class="go-game">Розпочати</button>
      </div>
    </div>`;
    const btn = el.querySelector('.go-game');
    btn.onclick = () => joinLobby(lobby.id);

    if (inLobby) {
        btn.disabled = true;
        btn.style.opacity = '0.5';
        btn.style.cursor = 'not-allowed';
    }
    else {
        btn.disabled = false;
        btn.style.opacity = '1';
        btn.style.cursor = 'pointer';
    }


}


async function renderMyLobby(lobby) {
    lobbyNameHeader.textContent = lobby.name;
    const playersProfiles = await Promise.all(
        lobby.players.map(id => fetchUserProfile(id))
    );

    const creatorId = lobby.creator;
    isCreater = creatorId === String(currentUserId);

    const idx = playersProfiles.findIndex(p => p.id === creatorId);

    if (idx > 0) {
        const [creatorProfile] = playersProfiles.splice(idx, 1);
        playersProfiles.unshift(creatorProfile);
    }

    lobbyMid.innerHTML = '';
    for (let i = 0; i < lobby.max_players; i++) {
        const slot = document.createElement('div');
        slot.classList.add('user-box');
        if (i < playersProfiles.length) {
            const player = playersProfiles[i];
            slot.dataset.userId = player.id;
            slot.classList.add(i === 0 ? 'creator-slot' : 'occupied-slot');
            if (player.id === String(currentUserId)) {
                slot.classList.add('my-slot');
            }

            const img = document.createElement('img');
            img.src = playersProfiles[i].avatar;
            img.alt = playersProfiles[i].username;
            img.classList.add('player-avatar');
            slot.appendChild(img);

            if (i > 0) {
                slot.addEventListener('contextmenu', e => {
                    if (isCreater) {
                        e.preventDefault();
                        showParticipantMenu(player.id, lobby.id, slot);
                    }
                });
            }
        }
        else {
            slot.classList.add('empty-slot');
            slot.addEventListener('mouseenter', () => {
                if (isCreater) {
                    slot.classList.add('show-add-icon');
                }
            });
            slot.addEventListener('mouseleave', () => {
                slot.classList.remove('show-add-icon');
            });
            slot.addEventListener('click', () => {
                if (isCreater) {
                    showInviteDialog(lobby.id);
                }
            });
        }
        lobbyMid.appendChild(slot);
    }

    disableMainControls();
    inLobby = true;

    if (isCreater) {
        deleteBtn.onclick = () => deleteLobby(lobby.id);
        startBtn.classList.remove('hidden');
        startBtn.disabled = lobby.players_count < lobby.max_players;
        startBtn.onclick = () => startGame(lobby.id);
        startBtn.style.opacity = startBtn.disabled ? '0.5' : '1';
        startBtn.style.cursor = startBtn.disabled ? 'not-allowed' : 'pointer';
    } else {
        startBtn.classList.add('hidden');
        deleteBtn.onclick = () => leaveLobby(lobby.id);
    }
}

function disableMainControls() {
    lobbyBlock.style.opacity = '1';
    lobbyBlock.style.pointerEvents = 'auto';

    createBtn.disabled = true;
    createBtn.style.opacity = '0.5';
    createBtn.style.cursor = 'not-allowed';

    playersSelect.disabled = true;
    playersSelect.style.opacity = '0.5';
    playersSelect.style.cursor = 'not-allowed';

    regionSelect.disabled = true;
    regionSelect.style.opacity = '0.5';
    regionSelect.style.cursor = 'not-allowed';

    lobbyNameInput.disabled = true;
    lobbyNameInput.style.opacity = '0.5';
    lobbyNameInput.style.cursor = 'not-allowed';

    startSearchBtn.disabled = true;
    startSearchBtn.style.opacity = '0.5';
    startSearchBtn.style.cursor = 'not-allowed';

    closedLobbySelector.disabled = true;
    closedLobbySelector.style.opacity = '0.5';
    closedLobbySelector.style.cursor = 'not-allowed';

    disableLobbyJoinButtons();
}

function enableMainControls() {
    lobbyBlock.style.opacity = '0';
    lobbyBlock.style.pointerEvents = 'none';

    createBtn.disabled = false;
    createBtn.style.opacity = '1';
    createBtn.style.cursor = 'pointer';

    playersSelect.disabled = false;
    playersSelect.style.opacity = '1';
    playersSelect.style.cursor = 'pointer';

    regionSelect.disabled = false;
    regionSelect.style.opacity = '1';
    regionSelect.style.cursor = 'pointer';

    lobbyNameInput.disabled = false;
    lobbyNameInput.style.opacity = '1';
    lobbyNameInput.style.cursor = 'pointer';

    startSearchBtn.disabled = false;
    startSearchBtn.style.opacity = '1';
    startSearchBtn.style.cursor = 'pointer';

    closedLobbySelector.disabled = false;
    closedLobbySelector.style.opacity = '1';
    closedLobbySelector.style.cursor = 'pointer';

    enableLobbyJoinButtons();
}

function disableLobbyJoinButtons() {
    document
        .querySelectorAll('.lobby-item .go-game')
        .forEach(btn => {
            btn.disabled = true;
            btn.style.opacity = '0.5';
            btn.style.cursor = 'not-allowed';
        });
}

function enableLobbyJoinButtons() {
    document
        .querySelectorAll('.lobby-item .go-game')
        .forEach(btn => {
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
        });
}

//-------------------------LobbyRendering-------------------------

//-------------------------ParticipantMenu-------------------------
function removeExistingMenu() {
    document.querySelectorAll('.participant-menu').forEach(m => m.remove());
}

function showParticipantMenu(userId, lobbyId, slot) {
    removeExistingMenu();

    const menu = document.createElement('div');
    menu.className = 'participant-menu';

    const btn = document.createElement('button');
    btn.textContent = 'Видалити з лобі';
    btn.onclick = async () => {
        await removeParticipantFromLobby(lobbyId, userId);
        menu.remove();
    };

    menu.appendChild(btn);
    menu.style.top = slot.getBoundingClientRect().bottom + 'px';
    menu.style.left = slot.getBoundingClientRect().left + 'px';
    document.body.appendChild(menu);
    document.addEventListener('click', removeExistingMenu, { once: true });
}


//-------------------------ParticipantMenu-------------------------
function authHeaders() {
    const token = localStorage.getItem('authToken');
    return token
        ? { 'Authorization': 'Bearer ' + token }
        : {};
}


const API_HOST = 'http://localhost:8000';
const API_BASE = `${API_HOST}/api/lobbies`;


async function createLobby(payload) {
    const res = await fetch(`${API_BASE}/create/`, {
        method: 'POST',
        headers: Object.assign({ 'Content-Type': 'application/json' }, authHeaders()),
        body: JSON.stringify(payload),
    });
    if (!res.ok) alert('Помилка у створенні: ' + res.status);
    inLobby = true;
}

async function joinLobby(id) {
    const res = await fetch(`${API_BASE}/${id}/join/`, {
        method: 'POST',
        headers: authHeaders(),
    });
    if (!res.ok) alert('Помилка join: ' + res.status);
    const el = document.getElementById('lobby-' + id);
    if (el) el.remove();
    inLobby = true;
}

async function leaveLobby(id) {
    const res = await fetch(`${API_BASE}/${id}/leave/`, {
        method: 'POST',
        headers: authHeaders(),
    });
    if (!res.ok) alert('Помилка leave: ' + res.status);
    enableMainControls();
    inLobby = false;
}

async function deleteLobby(id) {
    if (!confirm('Ви впевнені, що хочете повністю видалити це лоббі?')) {
        return;
    }

    const res = await fetch(`${API_BASE}/${id}/delete/`, {
        method: 'POST',
        headers: authHeaders()
    });

    if (!res.ok) alert('Помилка delete: ' + res.status);
}

async function removeParticipantFromLobby(lobbyId, userId) {
    const res = await fetch(`${API_BASE}/${lobbyId}/remove/${userId}/`, {
        method: 'DELETE',
        headers: Object.assign({ 'Content-Type': 'application/json' }, authHeaders()),
    });

    if (!res.ok) {
        const error = await res.json().catch(() => ({}));
        alert('Не видалось видалити учасника: ' + (error.detail || res.status));
    }
}

async function startGame(lobbyId) {
    const res = await fetch(`${API_BASE}/${lobbyId}/start/`, {
        method: 'POST',
        headers: Object.assign({ 'Content-Type': 'application/json' }, authHeaders())
    });
    if (!res.ok) {
        const error = await res.json().catch(() => ({}));
        return alert('Не вийшло почати гру: ' + (error.detail || res.status));
    }
}


async function fetchUserProfile(id) {
    const res = await fetch(`${API_HOST}/profile/${id}/info/`, {
        headers: authHeaders()
    });
    if (!res.ok) throw new Error(`Не вдалося отримати профіль ${id}`);
    const data = await res.json();
    data.id = id;
    return data;
}

async function fetchUserRank() {
    try {
        const res = await fetch(`${API_HOST}/statistic/user-rank/`, {
            headers: authHeaders()
        });
        if (!res.ok) {
            throw new Error(`Ошибка ${res.status}: не вдалося отримати дані рангу`);
        }

        const { points, rank } = await res.json();

        const rankDisplay = rank > 999 ? 'top 999+' : `top ${rank}`;

        document.getElementById('userRank').innerText = rankDisplay;
        document.getElementById('userPoints').innerText = points;

    } catch (err) {
        console.error(err);
        document.getElementById('userRank').innerText = '—';
        document.getElementById('userPoints').innerText = '—';
    }
}

async function fetchMe() {
    const res = await fetch('http://localhost:8000/auth/profile/', {
        headers: authHeaders()
    });
    const me = await res.json();
    currentUserId = me.id;
}