//---Оголошення змінних---
const form = document.getElementById('registrationForm');
const switchModeLink = document.getElementById('switchModeLink');
const formTitleSpan = document.querySelector('.form-title span');
const submitBtn = document.getElementById('submitBtn');
const nicknameBlock = document.getElementById('nicknameBlock');
const genderBlock = document.getElementById('genderBlock');
const nickname = document.getElementById('nickname');
const genderMale = genderBlock.querySelector('input[value="male"]');
const genderFem = genderBlock.querySelector('input[value="female"]');
//---Оголошення змінних---

let isLoginMode = false;

//---Обробник подій для форми---
form.addEventListener('submit', function (e) {

  e.preventDefault(); //---Скасування стандартної поведіники форми, щоб не було перезавантаження сторінки---

  //---Випадок "вхід", отримання значень з полів---
  if (isLoginMode) {
    const emailValue = document.getElementById('email').value;
    const passwordValue = document.getElementById('password').value;

    //---Пост запит для входу---
    fetch('http://127.0.0.1:8000/auth/login/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: emailValue,
        password: passwordValue
      }),
    })
      //---Парс у форматі json---
      .then(response => response.json())
      .then(data => {
        if (data.access) {
          localStorage.setItem('authToken', data.access);
          window.location.href = '../MainPage/mainPage.html';
          console.log(data);
        } else {
          showFieldError("password", 'Неправильний пароль або пошта!')
          console.log('Токен не отримано');
        }
      })
      //---Обробка помилки запиту---
      .catch(error => {
        console.log('Помилка входу');
        console.error(error);
      });

    return;
  }

  //---Змінні паролю---
  const password = document.getElementById('password').value;
  const repeatPassword = document.getElementById('repeatPassword').value;

  //---Перевірка на співпадання введених даних з 2 полів---
  if (password !== repeatPassword) {
    showFieldError("repeatPassword", 'Паролі не співпадають!')
    return;
  }

  //---Отримання значень---
  const nicknameValue = nickname.value;
  const genderValue = genderMale.checked ? 'male' : 'female';
  const emailValue = document.getElementById('email').value;

  //---Поста запит на реєстрацію---
  fetch('http://127.0.0.1:8000/auth/register/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      email: emailValue,
      password: password,
      username: nicknameValue,
      gender: genderValue
    }),
  })
    //---Парс у форматі json---
    .then(response => response.json())
    .then(data => {
      if (data.access) {
        localStorage.setItem('authToken', data.access);
        window.location.href = '../MainPage/mainPage.html';
        form.reset();
        console.log(data);
      } else if (data.errors) {
        console.log("Validation errors:", data.errors);

        //---Співставлення імен полів з їх айді---
        const fieldMap = {
          username: "nickname",
          email: "email",
          password: "password",
          gender: "genderMale"
        };

        //---Показ повідомлення для кожного поля де є помилка---
        Object.keys(data.errors).forEach(field => {
          const fieldId = fieldMap[field] || field;
          const messages = data.errors[field];

          if (Array.isArray(messages)) {
            showFieldError(fieldId, messages[0]);
          } else if (typeof messages === "string") {
            showFieldError(fieldId, messages);
          }
        });
      }
    })

    .catch(error => {
      console.error(error);
    });
});

//---Обробник кліку---
switchModeLink.addEventListener('click', function (e) {
  e.preventDefault();
  toggleMode(); //---Виклик функції---
});

//---Функція перемикання режиму---
function toggleMode() {
  if (!isLoginMode) {
    switchToLogin();
  } else {
    switchToRegistration();
  }
}

//---Функція очистки полів---
function clearFormFields() {
  email.value = '';
  password.value = '';
  repeatPassword.value = '';
  nickname.value = '';
  genderMale.checked = false;
  genderFem.checked = false;

  clearFieldError('email');
  clearFieldError('password');
  clearFieldError('repeatPassword');
  clearFieldError('nickname');
  clearFieldError('genderMale');
  clearFieldError('genderFem');
}

//---Функція очистки полів помилок---
function clearFieldError(fieldId) {
  const input = document.getElementById(fieldId);
  const errorDiv = document.getElementById(fieldId + 'Error');

  if (!input || !errorDiv) return;

  input.classList.remove('input-error');
  errorDiv.textContent = '';
  errorDiv.style.display = 'none';
}

const resetPasswordLink = document.getElementById('resetPasswordLink');

//---Функція перемикання у режим реєстрації---
function switchToLogin() {
  isLoginMode = true;
  formTitleSpan.textContent = 'Вхід';
  switchModeLink.textContent = 'Не має акаунту? Зареєструйтесь';
  submitBtn.textContent = 'Вхід';

  nicknameBlock.style.display = 'none';
  genderBlock.style.display = 'none';
  repeatPassword.style.display = 'none';
  resetPasswordLink.style.display = 'block';

  nickname.removeAttribute('required');
  genderMale.removeAttribute('required');
  genderFem.removeAttribute('required');
  repeatPassword.removeAttribute('required');

  clearFormFields();
}

//---Функція перемикання у режим входу---
function switchToRegistration() {
  isLoginMode = false;
  formTitleSpan.textContent = 'Реєстрація';
  switchModeLink.textContent = 'Маєте акаунт? Увійти';
  submitBtn.textContent = 'Реєстрація';

  nicknameBlock.style.display = 'block';
  genderBlock.style.display = 'flex';
  repeatPassword.style.display = 'block';
  resetPasswordLink.style.display = 'none';

  nickname.setAttribute('required', 'true');
  genderMale.setAttribute('required', 'true');
  genderFem.setAttribute('required', 'true');
  repeatPassword.setAttribute('required', 'true');

  clearFormFields();
}

//---Обробник кнопки для ресету паролю---
resetPasswordLink.addEventListener('click', function (e) {
  e.preventDefault();

  const emailValue = document.getElementById('email').value;
  if (!emailValue) {
    showFieldError("email", "Будь ласка, введіть email для відновлення паролю.");
    return;
  }

  //---Пост запит на відновлення паролю---
  fetch('http://127.0.0.1:8000/auth/forgot-password/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      email: emailValue
    }),
  })
    .then(response => {
      if (!response.ok) throw new Error("Не вдалося надіслати запит.");
      return response.json();
    })
    .then(data => {
      alert("Новий пароль надіслано на вказану пошту!");
    })
    .catch(error => {
      console.error(error);
      alert("Виникла помилка при відновленні паролю.");
    });
});

//---Показ повідомлень про помилку---
function showFieldError(fieldId, message) {
  const input = document.getElementById(fieldId);
  const errorDiv = document.getElementById(fieldId + 'Error');

  if (!input || !errorDiv) return;

  input.classList.add('input-error');
  errorDiv.textContent = message;
  errorDiv.style.display = 'block';

  input.addEventListener('input', function clearError() {
    input.classList.remove('input-error');
    errorDiv.style.display = 'none';
    input.removeEventListener('input', clearError);
  });
}